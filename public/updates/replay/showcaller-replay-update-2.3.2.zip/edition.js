// Which app this is. The same code makes two apps: Showcaller Replay (recording, plus instant replay out over NDI) and
// Showcaller ISO (recording only). package.json's "edition" says which ("iso" for ISO; SC_EDITION overrides it, for tests).
const edition = process.env.SC_EDITION || require('./package.json').edition || 'replay';
const iso = edition === 'iso';
module.exports = {
  iso, replay: !iso, edition: iso ? 'iso' : 'replay',
  name: iso ? 'Showcaller ISO' : 'Showcaller Replay',
  sub: iso ? 'ISO' : 'REPLAY', // shown small under the name
};
