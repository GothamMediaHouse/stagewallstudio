// Recording for Showcaller Replay: every chosen NDI source to its own .mov, all at once (replay.js plays them back).
// One FFmpeg per source. Pictures go in raw (UYVY, as NDI sends them) on FFmpeg's stdin and sound as 48 kHz float
// stereo on a second pipe, written together a frame at a time, so picture and sound can't drift apart.
// The files run on the wall clock: a frame the source didn't send (a hiccup, or the source going away) is filled with
// the last picture and silence, and a frame too many is left out. So every file in a take is the same length and
// carries time-of-day timecode, and they line up in the edit.
const { spawn, execFile } = require('child_process');
const { EventEmitter } = require('events');
const fs = require('fs');
const ED = require('./edition');
const path = require('path');

const RATE = 48000;

// ---------- FFmpeg ----------
// The one built into the app (ffmpeg-static), or for testing ISO_FFMPEG, or one installed on this computer.
function ffmpegPath() {
  const list = [];
  if (process.env.ISO_FFMPEG) list.push(process.env.ISO_FFMPEG);
  try { const p = require('ffmpeg-static'); if (p) list.push(p.replace('app.asar', 'app.asar.unpacked')); } catch {}
  if (process.platform !== 'win32') list.push('/opt/homebrew/bin/ffmpeg', '/usr/local/bin/ffmpeg', '/usr/bin/ffmpeg');
  return list.find((f) => { try { return fs.statSync(f).isFile(); } catch { return false; } }) || null;
}

// What to record as. ProRes for editing (bigger files), H.264 for smaller files.
const CODECS = {
  'prores-hq': { label: 'Apple ProRes 422 HQ', kind: 'prores', vt: 'hq', ks: 3, mbps1080p30: 220 },
  'prores-422': { label: 'Apple ProRes 422', kind: 'prores', vt: 'standard', ks: 2, mbps1080p30: 147 },
  'prores-lt': { label: 'Apple ProRes 422 LT', kind: 'prores', vt: 'lt', ks: 1, mbps1080p30: 102 },
  'prores-proxy': { label: 'Apple ProRes 422 Proxy', kind: 'prores', vt: 'proxy', ks: 0, mbps1080p30: 45 },
  h264: { label: 'H.264 (smaller files)', kind: 'h264', mbps1080p30: 25 },
};
// The encoders to try for each kind, best first. The graphics chip's (VideoToolbox on a Mac, NVIDIA or Intel on
// Windows) leaves the processor free for more sources.
const ENCODERS = { prores: ['prores_videotoolbox', 'prores_ks'], h264: ['h264_videotoolbox', 'h264_nvenc', 'h264_qsv', 'libx264'] };

// H.264 bit rate: about 25 Mb/s for 1080p30, more for bigger or faster pictures.
const h264Rate = (w, h, fps) => `${Math.max(4, Math.round((w * h * Math.min(fps, 120) * 0.4) / 1e6))}M`;
function videoArgs(codec, enc, { w, h, fps }) {
  const c = CODECS[codec];
  // a key frame every second: the file is written a piece at a time from one key frame to the next, and replay can
  // only play what has been written, so this keeps replay close to live
  const gop = ['-g', String(Math.max(1, Math.round(fps)))];
  switch (enc) {
    case 'prores_videotoolbox': return ['-c:v', enc, '-profile:v', c.vt];
    case 'prores_ks': return ['-c:v', enc, '-profile:v', String(c.ks), '-pix_fmt', 'yuv422p10le', '-vendor', 'apl0'];
    case 'h264_videotoolbox': return ['-c:v', enc, '-b:v', h264Rate(w, h, fps), '-profile:v', 'high', '-pix_fmt', 'nv12', '-realtime', '1', ...gop];
    case 'h264_nvenc': return ['-c:v', enc, '-preset', 'p4', '-rc', 'vbr', '-cq', '19', '-b:v', h264Rate(w, h, fps), '-pix_fmt', 'yuv420p', ...gop];
    case 'h264_qsv': return ['-c:v', enc, '-b:v', h264Rate(w, h, fps), '-pix_fmt', 'nv12', ...gop];
    default: return ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', ...gop];
  }
}

// Which encoders this computer's FFmpeg can actually use: each is tried on a few frames.
function tryEncoder(bin, codec, enc) {
  return new Promise((resolve) => {
    const args = ['-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i', 'color=c=black:s=1280x720:r=25,format=uyvy422', '-frames:v', '3',
      ...videoArgs(codec, enc, { w: 1280, h: 720, fps: 25 }), '-f', 'null', '-'];
    execFile(bin, args, { timeout: 20000 }, (err) => resolve(!err));
  });
}
async function detectEncoders(bin) {
  const out = {};
  if (!bin) return out;
  for (const [kind, list] of Object.entries(ENCODERS)) {
    const codec = kind === 'prores' ? 'prores-422' : 'h264';
    for (const enc of list) if (await tryEncoder(bin, codec, enc)) { out[kind] = enc; break; }
  }
  return out;
}

// ---------- timecode ----------
// Frame n (counted at the real rate) as a timecode label. 29.97 and 59.94 use drop-frame (with ';'), like cameras do.
function timecode(n, N, D) {
  const nominal = Math.max(1, Math.round(N / D)), drop = D === 1001 && (nominal === 30 || nominal === 60) ? nominal / 15 : 0;
  if (drop) {
    const per10 = nominal * 600 - drop * 9, perMin = nominal * 60 - drop;
    const d = Math.floor(n / per10), m = n % per10;
    n += drop * 9 * d + (m > drop ? drop * Math.floor((m - drop) / perMin) : 0);
  }
  n %= nominal * 86400;
  const ff = n % nominal, s = Math.floor(n / nominal), p = (x) => String(x).padStart(2, '0');
  return `${p(Math.floor(s / 3600))}:${p(Math.floor(s / 60) % 60)}:${p(s % 60)}${drop ? ';' : ':'}${p(ff)}`;
}
// The time of day at `ms` (local time) as a frame count at this rate.
const sinceMidnight = (ms) => { const d = new Date(ms); return (ms - new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime()) / 1000; };
const frameOfDay = (ms, N, D) => Math.floor((sinceMidnight(ms) * N) / D + 1e-6);
const todTimecode = (ms, N, D) => timecode(frameOfDay(ms, N, D), N, D);

// A source name as a file name: NDI names look like "MACHINE (Camera 1)".
const safeName = (s) => String(s).replace(/[\\/:*?"<>|\x00-\x1f]+/g, '-').replace(/\s+/g, ' ').trim().slice(0, 120) || 'Source';

// ---------- sound ----------
// A ring of interleaved stereo samples at 48 kHz, filled as sound arrives and emptied a frame's worth at a time.
class Ring {
  constructor(seconds = 4) { this.buf = new Float32Array(RATE * 2 * seconds); this.r = 0; this.n = 0; this.pos = 0; }
  get size() { return this.n / 2; } // stereo samples waiting
  clear() { this.r = 0; this.n = 0; }
  push(left, right, rate) {
    const cap = this.buf.length;
    const put = (l, r) => {
      if (this.n >= cap) { this.r = (this.r + 2) % cap; this.n -= 2; } // full: lose the oldest
      const w = (this.r + this.n) % cap; this.buf[w] = l; this.buf[w + 1] = r; this.n += 2;
    };
    if (rate === RATE) { for (let k = 0; k < left.length; k++) put(left[k], right[k]); return; }
    // another rate (44.1 kHz, 96 kHz…): to 48 kHz by straight-line steps between samples
    const step = rate / RATE, n = left.length;
    for (; this.pos < n - 1; this.pos += step) {
      const i = Math.floor(this.pos), f = this.pos - i;
      put(left[i] + (left[i + 1] - left[i]) * f, right[i] + (right[i + 1] - right[i]) * f);
    }
    this.pos -= n - 1;
  }
  drop(k) { k = Math.min(k, this.size); this.r = (this.r + k * 2) % this.buf.length; this.n -= k * 2; }
  // k stereo samples as little-endian float bytes; short of sound, the rest is silence
  take(k) {
    const out = new Float32Array(k * 2), have = Math.min(k * 2, this.n), cap = this.buf.length;
    for (let i = 0; i < have; i++) out[i] = this.buf[(this.r + i) % cap];
    this.r = (this.r + have) % cap; this.n -= have;
    return Buffer.from(out.buffer);
  }
}

// ---------- one source ----------
// A source can change size or rate in the middle of a take; it then goes on in a new file ("… part 2.mov").
// If FFmpeg stops by itself, the next picture starts a new part too (up to 5 times).
const BACKLOG_FRAMES = 15, BACKLOG_BYTES = 64e6; // pictures waiting for FFmpeg (half a second, at most 64 MB) before more are left out
const SLACK = 0.45; // how far off its frame (in frames) a picture can arrive before it's treated as early or late
class Track extends EventEmitter {
  constructor({ name, dir, codec, encoders, crashSafe, bin, t0 }) {
    super();
    Object.assign(this, { name, dir, codec, encoders, crashSafe, bin, t0 });
    this.base = safeName(name);
    this.ring = new Ring();
    this.seg = null; this.parts = []; this.failures = 0; this.ended = false; this.error = '';
    this.frames = 0; this.repeats = 0; this.dropped = 0; this.skipped = 0; this.trimmed = 0; this.gaps = 0;
    this.lastAt = 0; this.missing = false;
  }
  enc() { return this.encoders[CODECS[this.codec].kind]; }
  open(f) {
    this.closeSeg();
    if (this.failures > 5) return;
    const n = this.parts.length + 1, file = path.join(this.dir, `${this.base}${n > 1 ? ` part ${n}` : ''}.mov`);
    // The first part starts when Record was pressed (if the source was there), so every file in the take starts together.
    const start = !this.parts.length && f.at - this.t0 < 1000 ? this.t0 : f.at;
    const fps = f.N / f.D, hd = f.h >= 720, enc = this.enc();
    const tc = todTimecode(start, f.N, f.D);
    const args = ['-hide_banner', '-loglevel', 'error', '-nostats',
      // no probing: the formats are given, and probing the sound would hold up the pictures for seconds
      '-thread_queue_size', '16', '-probesize', '32', '-analyzeduration', '0', '-f', 'rawvideo', '-pix_fmt', f.fmt === 'bgra' ? 'bgra' : 'uyvy422', '-s', `${f.w}x${f.h}`, '-framerate', `${f.N}/${f.D}`, '-i', 'pipe:0',
      '-thread_queue_size', '512', '-probesize', '32', '-analyzeduration', '0', '-f', 'f32le', '-ar', String(RATE), '-ac', '2', '-i', 'pipe:3',
      '-map', '0:v', '-map', '1:a',
      ...(f.fmt === 'bgra' ? ['-vf', `scale=out_color_matrix=${hd ? 'bt709' : 'bt601'}:out_range=tv`] : []),
      ...videoArgs(this.codec, enc, { w: f.w, h: f.h, fps }),
      '-color_primaries', hd ? 'bt709' : 'smpte170m', '-color_trc', hd ? 'bt709' : 'smpte170m', '-colorspace', hd ? 'bt709' : 'smpte170m', '-color_range', 'tv',
      '-c:a', 'pcm_s24le',
      '-timecode', tc,
      '-metadata', `title=${this.name}`, '-metadata', `comment=Recorded by ${ED.name} from the NDI source ${this.name}`,
      // written half a second at a time (from key frame to key frame), so the file can be replayed while it's
      // recording, and a crash or power cut loses at most the last moment
      '-movflags', '+frag_keyframe+empty_moov+delay_moov', '-frag_duration', '500000',
      '-f', 'mov', '-y', file];
    let proc;
    try { proc = spawn(this.bin, args, { stdio: ['pipe', 'ignore', 'pipe', 'pipe'], windowsHide: true }); }
    catch (e) { this.fail(e.message); return; }
    const seg = { proc, file, w: f.w, h: f.h, fmt: f.fmt, N: f.N, D: f.D, t0: start, tc, written: 0, acc: 0, last: null, err: '', done: null, frameBytes: f.data.length };
    seg.done = new Promise((resolve) => {
      proc.on('close', (code) => {
        if (this.seg === seg && !this.ended) { this.seg = null; this.fail(seg.err || `FFmpeg stopped (${code}).`); }
        resolve(code);
      });
      proc.on('error', (e) => { seg.err = e.message; });
    });
    proc.stderr.on('data', (d) => { const s = String(d).trim(); if (s) seg.err = s.split('\n').pop().slice(0, 300); });
    for (const p of [proc.stdin, proc.stdio[3]]) p.on('error', () => {}); // a pipe closing under us is handled by 'close'
    this.seg = seg; this.ring.clear();
    this.parts.push({ file, w: f.w, h: f.h, N: f.N, D: f.D, fps: Math.round(fps * 100) / 100, fmt: f.fmt, tc, start, encoder: enc });
    this.emit('part', this.parts[this.parts.length - 1]);
  }
  fail(msg) { this.failures++; this.error = msg; this.emit('trouble', msg); }
  closeSeg() {
    const s = this.seg;
    if (!s) return null;
    this.seg = null;
    try { s.proc.stdin.end(); } catch {}
    try { s.proc.stdio[3].end(); } catch {}
    return s;
  }
  backed() { const s = this.seg; return !s || s.proc.stdin.writableLength > Math.min(s.frameBytes * BACKLOG_FRAMES, BACKLOG_BYTES); }
  // One frame of picture and the sound that goes with it.
  write(data) {
    const s = this.seg;
    s.acc += (RATE * s.D) / s.N;
    const k = Math.floor(s.acc); s.acc -= k;
    // More sound waiting than the frame needs (it ran ahead, or a source's clock is a little fast): let some go
    // so the sound stays with the picture.
    const extra = this.ring.size - k;
    if (extra > RATE * 0.2) { const lose = Math.round(extra - RATE * 0.06); this.ring.drop(lose); this.trimmed += lose; }
    s.proc.stdin.write(data);
    s.proc.stdio[3].write(this.ring.take(k));
    s.written++; s.last = data; this.frames++;
  }
  due(now) { const s = this.seg; return Math.floor(((now - s.t0) * s.N) / (s.D * 1000)) + 1; } // frames the file should have by now
  frame(f) {
    if (this.ended) return;
    const s = this.seg;
    if (!s || s.w !== f.w || s.h !== f.h || s.fmt !== f.fmt || s.N !== f.N || s.D !== f.D) this.open(f);
    if (!this.seg) return;
    if (this.missing) { this.missing = false; this.emit('back'); }
    this.lastAt = f.at;
    // Where this picture falls in the file, in frames. Pictures arrive a few milliseconds early or late, so a
    // picture is only left out, or the one before repeated, when it's off by nearly half a frame: otherwise a source
    // whose pictures happen to arrive right at a frame boundary would get a repeat and a skip every few frames.
    const x = ((f.at - this.seg.t0) * this.seg.N) / (this.seg.D * 1000);
    if (this.seg.written >= Math.floor(x + SLACK) + 1) { this.skipped++; return; } // the source is a little faster than its rate
    if (this.backed()) { this.dropped++; this.seg.pending = f.data; return; } // FFmpeg can't keep up: filled in later
    this.fill(Math.floor(x - SLACK));
    if (this.backed()) { this.dropped++; this.seg.pending = f.data; return; }
    this.write(f.data);
  }
  // Repeat the last picture up to frame `upTo` (a hiccup, or the source has gone).
  fill(upTo) {
    const s = this.seg;
    if (!s || !(s.last || s.pending)) return;
    let n = 0;
    while (s.written < upTo && !this.backed() && n++ < 120) { this.write(s.pending || s.last); this.repeats++; s.pending = null; }
  }
  audio(a) { if (!this.ended) this.ring.push(a.left, a.right, a.rate); }
  // Ten times a second: keep a source that has gone quiet running on the wall clock.
  tick(now) {
    const s = this.seg;
    if (!s || this.ended) return;
    if (now - this.lastAt > 300) {
      if (!this.missing && now - this.lastAt > 1000) { this.missing = true; this.gaps++; this.emit('gone'); }
      this.fill(this.due(now) - 1);
    }
  }
  bytes() { let b = 0; for (const p of this.parts) { try { b += fs.statSync(p.file).size; } catch {} } return b; }
  async stop() {
    if (this.ended) return;
    this.tick(Date.now());
    this.ended = true;
    const s = this.closeSeg();
    if (!s) return;
    const t = setTimeout(() => { try { s.proc.kill('SIGKILL'); } catch {} }, 30000);
    await s.done; clearTimeout(t);
  }
  status(now = Date.now()) {
    const s = this.seg, p = this.parts[this.parts.length - 1];
    return {
      name: this.name, recording: !!s, waiting: !this.parts.length, missing: this.missing, error: this.error,
      file: p ? path.basename(p.file) : '', parts: this.parts.length, w: p?.w || 0, h: p?.h || 0, fps: p?.fps || 0, encoder: p?.encoder || '',
      frames: this.frames, repeats: this.repeats, dropped: this.dropped, skipped: this.skipped, gaps: this.gaps,
      seconds: p ? (now - this.parts[0].start) / 1000 : 0, bytes: this.bytes(), lastAt: this.lastAt,
    };
  }
}

// ---------- a take: every chosen source, at once ----------
const pad = (n) => String(n).padStart(2, '0');
function takeFolderName(when, name) {
  const d = new Date(when);
  const stamp = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}${pad(d.getMinutes())}`;
  const n = safeName(name || '').replace(/^Source$/, '');
  return n ? `${stamp} ${n}` : stamp;
}
const clock = (sec) => { const s = Math.max(0, sec); return `${pad(Math.floor(s / 3600))}:${pad(Math.floor(s / 60) % 60)}:${pad(Math.floor(s % 60))}.${String(Math.floor((s % 1) * 1000)).padStart(3, '0')}`; };

class Take extends EventEmitter {
  constructor({ ndi, bin, encoders, folder, sources, codec, crashSafe, name }) {
    super();
    this.t0 = Date.now();
    this.name = String(name || '').trim();
    let dir = path.join(folder, takeFolderName(this.t0, this.name));
    for (let i = 2; fs.existsSync(dir); i++) dir = path.join(folder, `${takeFolderName(this.t0, this.name)} (${i})`);
    fs.mkdirSync(dir, { recursive: true });
    this.dir = dir; this.codec = codec; this.markers = []; this.ended = false;
    // the take's own timecode (for markers) runs at the first source's rate, or 25
    const first = sources.map((s) => ndi.info(s)).find((x) => x && x.N);
    this.N = first?.N || 25; this.D = first?.D || 1;
    const used = new Set();
    this.tracks = sources.map((name) => {
      const t = new Track({ name, dir, codec, encoders, crashSafe, bin, t0: this.t0 });
      while (used.has(t.base.toLowerCase())) t.base += ' 2'; // two sources that make the same file name
      used.add(t.base.toLowerCase());
      t.on('trouble', (m) => this.emit('trouble', name, m));
      t.on('gone', () => this.emit('gone', name));
      t.on('back', () => this.emit('back', name));
      t.stopWatching = ndi.watch(name, { frame: (f) => t.frame(f), audio: (a) => t.audio(a) });
      if (!t.stopWatching) t.fail('That NDI source could not be opened.');
      return t;
    });
    this.timer = setInterval(() => { const now = Date.now(); for (const t of this.tracks) t.tick(now); }, 100);
  }
  mark(label) {
    const at = Date.now(), sec = (at - this.t0) / 1000;
    const m = { n: this.markers.length + 1, at, sec, time: clock(sec), tc: todTimecode(at, this.N, this.D), label: String(label || '').trim().slice(0, 200) || `Marker ${this.markers.length + 1}` };
    this.markers.push(m);
    this.writeMarkers();
    return m;
  }
  // markers.csv (for anyone), and markers.edl (DaVinci Resolve: Timeline → Import → Timeline Markers from EDL).
  writeMarkers() {
    const q = (s) => `"${String(s).replace(/"/g, '""')}"`;
    const csv = ['Marker,Name,Time into take,Timecode (time of day),Clock time',
      ...this.markers.map((m) => [m.n, q(m.label), m.time, m.tc, new Date(m.at).toLocaleTimeString()].join(','))].join('\r\n') + '\r\n';
    const drop = this.D === 1001 && [30, 60].includes(Math.round(this.N / this.D));
    const edl = [`TITLE: ${path.basename(this.dir)}`, `FCM: ${drop ? 'DROP FRAME' : 'NON-DROP FRAME'}`, ''];
    for (const m of this.markers) {
      const f = frameOfDay(m.at, this.N, this.D), a = timecode(f, this.N, this.D), b = timecode(f + 1, this.N, this.D);
      edl.push(`${String(m.n).padStart(3, '0')}  001      V     C        ${a} ${b} ${a} ${b}  `, ` |C:ResolveColorBlue |M:${m.label.replace(/[|\r\n]/g, ' ')} |D:1`, '');
    }
    try {
      fs.writeFileSync(path.join(this.dir, 'markers.csv'), csv);
      fs.writeFileSync(path.join(this.dir, 'markers.edl'), edl.join('\r\n'));
    } catch (e) { this.emit('trouble', '', `Couldn’t save the markers: ${e.message}`); }
  }
  bytes() { return this.tracks.reduce((a, t) => a + t.bytes(), 0); }
  status() {
    const now = Date.now();
    return { dir: this.dir, folder: path.basename(this.dir), t0: this.t0, seconds: (now - this.t0) / 1000, tc: todTimecode(this.t0, this.N, this.D), codec: this.codec,
      markers: this.markers, tracks: this.tracks.map((t) => t.status(now)) };
  }
  async stop() {
    if (this.ended) return this.summary;
    this.ended = true; this.endAt = Date.now();
    clearInterval(this.timer);
    for (const t of this.tracks) { try { t.stopWatching?.(); } catch {} }
    await Promise.all(this.tracks.map((t) => t.stop()));
    if (this.markers.length) this.writeMarkers();
    const st = this.status();
    // a note of what was recorded, next to the files
    const lines = [`${ED.name} take`, `Started ${new Date(this.t0).toLocaleString()} (timecode ${st.tc})`, `Length ${clock(st.seconds).slice(0, 8)}`, `Recorded as ${CODECS[this.codec].label}`, ''];
    for (const t of this.tracks) {
      const s = t.status();
      lines.push(`${t.name}`);
      if (!t.parts.length) lines.push(`  Nothing recorded${t.error ? `: ${t.error}` : ' (no picture came from this source)'}`);
      for (const p of t.parts) lines.push(`  ${path.basename(p.file)}: ${p.w}×${p.h} ${p.fps} fps, from ${new Date(p.start).toLocaleTimeString()} (timecode ${p.tc}), ${p.encoder}`);
      if (s.repeats || s.dropped || s.gaps) lines.push(`  ${s.repeats} frames repeated, ${s.dropped} left out because the computer was busy${s.gaps ? `, the source went away ${s.gaps} time${s.gaps > 1 ? 's' : ''}` : ''}`);
      lines.push('');
    }
    if (this.markers.length) lines.push(`${this.markers.length} marker${this.markers.length > 1 ? 's' : ''}: markers.csv, and markers.edl for DaVinci Resolve`);
    try { fs.writeFileSync(path.join(this.dir, 'Take info.txt'), lines.join('\r\n') + '\r\n'); } catch {}
    this.summary = { ...st, bytes: this.bytes() };
    return this.summary;
  }
}

module.exports = { ffmpegPath, detectEncoders, CODECS, ENCODERS, Take, Track, Ring, timecode, todTimecode, safeName, takeFolderName, videoArgs };
