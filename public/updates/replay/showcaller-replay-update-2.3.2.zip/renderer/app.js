// Showcaller Replay (and Showcaller ISO): the window. Sources on the left, their pictures in the middle, the replay on the right
// (not in ISO, which only records), the record deck along the bottom.
(async () => {
  const api = window.iso, $ = (id) => document.getElementById(id);
  // which app this is: Showcaller ISO hides everything to do with replay (style.css: .ronly, .ionly)
  const ISO = new URLSearchParams(location.search).get('edition') === 'iso', NAME = ISO ? 'Showcaller ISO' : 'Showcaller Replay';
  document.documentElement.dataset.edition = ISO ? 'iso' : 'replay';
  document.title = NAME; $('brandSub').textContent = ISO ? 'ISO' : 'REPLAY';
  for (const el of document.querySelectorAll('.appname')) el.textContent = NAME;
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const st = await api.state();
  let cfg = st.cfg, all = st.all, status = st.status, encoders = st.encoders, encodersReady = st.encodersReady;
  document.documentElement.classList.add(`os-${st.platform}`);
  const mac = st.platform === 'darwin';
  if (!mac) { $('recBtn').title = 'Record (Ctrl+R)'; $('stopBtn').title = 'Stop (Ctrl+.)'; }
  $('ver').textContent = `${NAME} ${st.version}`;

  // ---------- helpers ----------
  const pad = (n) => String(n).padStart(2, '0');
  const hms = (s) => { s = Math.max(0, Math.floor(s || 0)); return `${pad(Math.floor(s / 3600))}:${pad(Math.floor(s / 60) % 60)}:${pad(s % 60)}`; };
  const gb = (b) => (b >= 1e12 ? `${(b / 1e12).toFixed(2)} TB` : b >= 1e9 ? `${(b / 1e9).toFixed(1)} GB` : `${Math.round((b || 0) / 1e6)} MB`);
  const hoursMins = (s) => (s >= 3600 ? `${Math.floor(s / 3600)} h ${pad(Math.floor(s / 60) % 60)} min` : `${Math.max(1, Math.floor(s / 60))} min`);
  // NDI names look like "MACHINE (Source)"
  const split = (n) => { const m = /^(.*?) \((.*)\)$/.exec(n); return m ? { src: m[2], host: m[1] } : { src: n, host: '' }; };
  let toastT = null;
  const toast = (t, bad) => { const el = $('toast'); el.textContent = t; el.className = `toast${bad ? ' bad' : ''}`; el.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => (el.hidden = true), bad ? 6000 : 2600); };
  const recording = () => !!status?.take;

  // ---------- formats ----------
  const KIND_NAME = { prores_videotoolbox: 'the Mac’s video engine', prores_ks: 'the processor', h264_videotoolbox: 'the Mac’s video engine', h264_nvenc: 'the NVIDIA graphics card', h264_qsv: 'Intel Quick Sync', libx264: 'the processor' };
  function fillCodecs() {
    for (const sel of [$('codecSel'), $('sCodec')]) {
      sel.innerHTML = Object.entries(st.codecs).map(([k, c]) => {
        const kind = k.startsWith('prores') ? 'prores' : 'h264', can = !encodersReady || !!encoders[kind];
        return `<option value="${k}" ${can ? '' : 'disabled'}>${esc(c.label)}${can ? '' : ' (not on this computer)'}</option>`;
      }).join('');
      sel.value = cfg.codec;
    }
    const c = st.codecs[cfg.codec], kind = cfg.codec.startsWith('prores') ? 'prores' : 'h264', enc = encoders[kind];
    const perHour = (c.mbps * 3600) / 8 / 1000; // GB an hour for a 1080p30 source
    const note = !st.ffmpeg ? `FFmpeg is missing from the app: reinstall ${NAME}.`
      : !encodersReady ? 'Checking what this computer can record…'
        : !enc ? `This computer can’t record ${c.label}. Pick another format.`
          : `About ${perHour < 10 ? perHour.toFixed(1) : Math.round(perHour)} GB an hour for each 1080p30 source (double that at 60p). Encoded by ${KIND_NAME[enc] || enc}${enc === 'prores_ks' ? ', so fewer sources fit at once than with a Mac’s video engine' : ''}.`;
    $('codecNote').textContent = note; $('sCodecNote').textContent = note; $('codecSel').title = note;
  }

  // ---------- sources: the list on the left (every source found), the wall (the ticked ones) ----------
  const tiles = new Map(); // name -> { el, canvas, msg, meters, label, pic }
  const rowsEl = new Map(); // name -> li
  function sourceList() {
    const names = new Set([...all, ...cfg.sources]);
    return [...names].sort((a, b) => a.localeCompare(b));
  }
  function setTicked(name, on) {
    if (recording()) return;
    const set = new Set(cfg.sources);
    if (on) set.add(name); else set.delete(name);
    cfg.sources = sourceList().filter((n) => set.has(n));
    api.settings({ sources: cfg.sources }).then((x) => { cfg = x; drawSources(); });
    drawSources();
  }
  function row(name) {
    let li = rowsEl.get(name);
    if (li) return li;
    const s = split(name);
    li = document.createElement('li');
    li.title = name;
    li.innerHTML = `<input type="checkbox"><span class="st"></span><span class="nm"><b>${esc(s.src)}</b><small>${esc(s.host)}</small></span>`;
    const box = li.querySelector('input');
    box.onchange = () => setTicked(name, box.checked);
    li.onclick = (e) => { if (e.target !== box && !box.disabled) { box.checked = !box.checked; setTicked(name, box.checked); } };
    rowsEl.set(name, li);
    return li;
  }
  function tile(name) {
    let c = tiles.get(name);
    if (c) return c;
    if (ISO) return chan(name);
    const s = split(name), el = document.createElement('div');
    el.className = 'tile';
    el.title = name;
    el.innerHTML = `<canvas width="320" height="180"></canvas><div class="msg"></div><div class="tally"></div><span class="badge">REC</span><span class="outbadge">OUT</span>
      <div class="label"><b>${esc(s.src)}</b><span></span></div><div class="meters"><i></i><i></i></div>`;
    c = { el, canvas: el.querySelector('canvas'), msg: el.querySelector('.msg'), meters: el.querySelectorAll('.meters i'), line: el.querySelector('.label span'), pic: false };
    el.onclick = () => chooseAngle(name); // the angle that goes out (live, or the replay)
    tiles.set(name, c);
    return c;
  }
  // Showcaller ISO: a channel strip per source instead of a tile (the same picture, meters and format line)
  function chan(name) {
    const s = split(name), el = document.createElement('div');
    el.className = 'chan';
    el.title = name;
    el.innerHTML = `<div class="n"></div><div class="pic"><canvas width="320" height="180"></canvas><div class="msg"></div><span class="badge">● REC</span></div>
      <div class="nm"><b>${esc(s.src)}</b><small>${esc(s.host || 'This computer')}</small><code></code></div>
      <div class="meter"><i></i><i></i><small><span>−60</span><span>−18</span><span>0 dB</span></small></div>
      <div class="state"></div><div class="file"></div><div class="health"></div><button type="button" class="rm" title="Take this source out">✕</button>`;
    const c = { el, canvas: el.querySelector('canvas'), msg: el.querySelector('.msg'), meters: el.querySelectorAll('.meter i'), line: el.querySelector('.nm code'), pic: false,
      num: el.querySelector('.n'), state: el.querySelector('.state'), file: el.querySelector('.file'), health: el.querySelector('.health'), rm: el.querySelector('.rm') };
    c.rm.onclick = () => setTicked(name, false);
    tiles.set(name, c);
    api.thumbSize(name, (window.devicePixelRatio || 1) > 1 ? 320 : 160);
    return c;
  }
  const since = (ms) => { const x = Math.max(0, Math.floor((Date.now() - ms) / 1000)); return x >= 3600 ? hms(x) : `${Math.floor(x / 60)}:${pad(x % 60)}`; };
  function drawChans(ticked, tracks, info, rec) {
    const list = $('chanList');
    ticked.forEach((n, i) => {
      const c = tile(n), t = tracks.get(n), inf = info.get(n), online = all.includes(n);
      if (list.children[i] !== c.el) list.insertBefore(c.el, list.children[i] || null);
      const live = inf && inf.lastAt && Date.now() - inf.lastAt < 2000;
      if (!live) c.pic = false;
      c.canvas.style.visibility = live && c.pic ? 'visible' : 'hidden';
      c.msg.textContent = live ? (c.pic ? '' : 'Connecting…') : !online ? 'Not on the network' : 'Connecting…';
      c.num.textContent = i + 1;
      c.el.classList.toggle('rec', !!t?.recording);
      c.rm.disabled = rec;
      const codec = st.codecs[cfg.codec]?.label.replace('Apple ProRes', 'ProRes').replace(' (smaller files)', '') || '';
      let line = live && inf.w ? `${fmtLine(inf)}` : online ? 'On the network' : 'Not on the network now';
      if (t?.recording && t.w) line = `${t.w}×${t.h} ${t.fps} · ${codec}`;
      if (c.line.textContent !== line) c.line.textContent = line;
      // state, file and health
      let state = ['wait', 'Waiting'], file = '', health = ['', ''];
      if (t) {
        if (t.error && !t.recording) state = ['bad', 'Stopped'];
        else if (t.waiting) state = ['wait', 'Waiting'];
        else if (t.missing) state = ['wait', 'Holding'];
        else state = ['rec', '● Recording'];
        file = `${gb(t.bytes || 0)}<span>${esc(t.file || '…')}${t.parts > 1 ? ` · part ${t.parts}` : ''}</span>`;
        health = t.error && !t.recording ? ['bad', esc(t.error)]
          : t.missing ? ['warn', `Gone ${since(t.lastAt || Date.now())}`]
            : t.waiting ? ['warn', 'No picture yet']
              : t.dropped ? ['bad', `⚠ ${t.dropped} left out (busy)`]
                : t.gaps ? ['warn', `⚠ Went away ${t.gaps}×`]
                  : t.repeats > 15 ? ['warn', `⚠ ${t.repeats} repeated`] : ['ok', '✓ Clean'];
      } else if (live) { state = ['ready', 'Ready']; file = `<span>${esc(n.replace(/[\\/:*?"<>|]/g, '-'))}.mov</span>`; }
      else if (online) state = ['wait', 'Connecting'];
      else state = ['wait', 'Offline'];
      c.state.className = `state ${state[0]}`; c.state.textContent = state[1];
      if (c.fileHtml !== file) { c.file.innerHTML = file; c.fileHtml = file; }
      c.health.className = `health ${health[0]}`; c.health.innerHTML = health[1];
    });
    $('chanEmpty').hidden = ticked.length > 0; $('chans').querySelector('.chead').hidden = !ticked.length;
    // the sources on the network that aren't in yet
    const avail = all.filter((n) => !cfg.sources.includes(n));
    const html = rec ? '<span class="none">Stop recording to add or take out sources.</span>'
      : avail.length ? avail.map((n) => { const x = split(n); return `<button type="button" data-add="${esc(n)}" title="${esc(n)}">${esc(x.src)}${x.host ? `<small>${esc(x.host)}</small>` : ''}</button>`; }).join('')
        : `<span class="none">${st.ndi.ok ? 'No other NDI sources on the network.' : esc(st.ndi.reason || 'NDI isn’t running.')}</span>`;
    if ($('availList').dataset.html !== html) { $('availList').innerHTML = html; $('availList').dataset.html = html; }
    $('addAll').hidden = rec || avail.length < 2;
  }
  if (ISO) {
    $('availList').onclick = (e) => { const b = e.target.closest('[data-add]'); if (b) setTicked(b.dataset.add, true); };
    $('addAll').onclick = () => { if (recording()) return; cfg.sources = sourceList().filter((n) => all.includes(n) || cfg.sources.includes(n)); api.settings({ sources: cfg.sources }).then((x) => { cfg = x; drawSources(); }); drawSources(); };
    $('refreshBtn2').onclick = () => { api.ndiRefresh(); toast('Looking for NDI sources again'); };
    $('chans').appendChild($('logCard')); // messages go under the channels
  }
  // Lay the wall out like a multiview: the number of columns that makes the 16:9 tiles biggest.
  function fitWall() {
    const n = tiles.size, g = $('grid');
    if (!n || ISO) return;
    const W = g.clientWidth, H = g.clientHeight, gap = 8;
    let best = { size: 0, cols: 1, w: 0, h: 0 };
    for (let cols = 1; cols <= n; cols++) {
      const rows = Math.ceil(n / cols);
      const w = Math.min((W - gap * (cols - 1)) / cols, ((H - gap * (rows - 1)) / rows) * 16 / 9);
      if (w > best.w) best = { w, cols, h: w * 9 / 16 };
    }
    g.style.gridTemplateColumns = `repeat(${best.cols}, ${Math.floor(best.w)}px)`;
    g.style.gridAutoRows = `${Math.floor(best.h)}px`;
    // ask for previews as wide as the tiles are on screen (in steps, so resizing doesn't ask on every pixel)
    // (capped, so many big previews can't swamp the app: about 50 MB a second at most for one source, 100 for four)
    const cap = n === 1 ? 1280 : n <= 4 ? 960 : 640;
    const px = Math.min(cap, Math.ceil((best.w * (window.devicePixelRatio || 1)) / 160) * 160);
    for (const [name, c] of tiles) if (c.size !== px) { c.size = px; api.thumbSize(name, px); }
  }
  new ResizeObserver(fitWall).observe($('wall'));
  const fmtLine = (inf) => `${inf.w}×${inf.h} ${inf.fps}${inf.ch ? ` · ${inf.ch === 1 ? 'mono' : inf.ch === 2 ? 'stereo' : `${inf.ch} ch, rec 1–2`}` : ' · no sound'}${inf.fmt === 'bgra' ? ' · alpha' : ''}`;
  function drawSources() {
    const rs = rstate, list = sourceList(), rec = recording(), tracks = new Map((status?.take?.tracks || []).map((t) => [t.name, t]));
    const info = new Map((status?.sources || []).map((s) => [s.name, s]));
    // the list
    const ul = $('rows');
    for (const [n, li] of rowsEl) if (!list.includes(n)) { li.remove(); rowsEl.delete(n); }
    list.forEach((n, i) => {
      const li = row(n), on = cfg.sources.includes(n), inf = info.get(n), t = tracks.get(n), online = all.includes(n);
      if (ul.children[i] !== li) ul.insertBefore(li, ul.children[i] || null);
      const box = li.querySelector('input'); box.checked = on; box.disabled = rec;
      li.className = `${on ? 'on' : ''}${t?.recording ? ' rec' : ''}${rec ? ' locked' : ''}`;
      const live = inf && inf.lastAt && Date.now() - inf.lastAt < 2000;
      li.querySelector('.st').className = `st${live ? ' live' : on && !online ? ' gone' : ''}`;
      li.querySelector('.st').title = live ? 'Sending pictures' : online ? 'On the network' : 'Not on the network now';
    });
    // the wall
    const ticked = list.filter((n) => cfg.sources.includes(n)), grid = $('grid');
    for (const [n, c] of tiles) if (!ticked.includes(n)) { c.el.remove(); tiles.delete(n); }
    if (ISO) return drawChans(ticked, tracks, info, rec);
    ticked.forEach((n, i) => {
      const c = tile(n), t = tracks.get(n), inf = info.get(n), online = all.includes(n);
      if (grid.children[i] !== c.el) grid.insertBefore(c.el, grid.children[i] || null);
      c.el.classList.toggle('rec', !!t && t.recording);
      c.el.classList.toggle('gone', !!t?.missing);
      c.el.classList.toggle('out', !!rs && rs.angle === n);
      const live = inf && inf.lastAt && Date.now() - inf.lastAt < 2000;
      if (!live) c.pic = false;
      c.canvas.style.visibility = live && c.pic ? 'visible' : 'hidden';
      c.msg.textContent = !online && !live ? 'Not on the network now' : live ? '' : 'Connecting…';
      let line = live && inf.w ? esc(fmtLine(inf)) : '';
      if (t) {
        if (t.error && !t.recording) line = `<span class="bad">${esc(t.error)}</span>`;
        else if (t.waiting) line = '<span class="warn">Waiting for a picture</span>';
        else if (t.missing) line = '<span class="warn">Source gone · holding the last picture</span>';
        else if (t.dropped) line += ` · <span class="bad">${t.dropped} repeated (busy)</span>`;
        if (t.parts > 1) line += ` · part ${t.parts}`;
      }
      if (c.lineHtml !== line) { c.line.innerHTML = line; c.lineHtml = line; }
    });
    $('wallEmpty').hidden = ticked.length > 0;
    fitWall();
    $('empty').hidden = list.length > 0;
    $('rows').hidden = !list.length;
    $('srcCount').textContent = list.length ? `${ticked.length} of ${list.length} ticked` : '';
    $('allBtn').disabled = rec || !all.length;
    $('allBtn').textContent = all.length && all.every((n) => cfg.sources.includes(n)) ? 'Untick all' : 'Tick all';
    $('srcHint').textContent = rec ? 'Locked while recording' : '';
  }
  $('allBtn').onclick = () => {
    const allOn = all.every((n) => cfg.sources.includes(n));
    cfg.sources = allOn ? [] : sourceList().filter((n) => all.includes(n) || cfg.sources.includes(n));
    api.settings({ sources: cfg.sources }).then((x) => { cfg = x; drawSources(); });
    drawSources();
  };
  $('refreshBtn').onclick = () => { api.ndiRefresh(); toast('Looking for NDI sources again'); };
  // The small pictures come as UYVY (most sources) or BGRA; turned into RGBA here (BT.709, video levels).
  const toRgba = (fmt, src, w, h) => {
    const out = new Uint8ClampedArray(w * h * 4);
    if (fmt === 'uyvy') {
      for (let i = 0, o = 0; i < src.length; i += 4, o += 8) {
        const U = src[i] - 128, V = src[i + 2] - 128, r = 1.793 * V, g = -0.213 * U - 0.533 * V, b = 2.112 * U;
        const y0 = 1.164 * (src[i + 1] - 16), y1 = 1.164 * (src[i + 3] - 16);
        out[o] = y0 + r; out[o + 1] = y0 + g; out[o + 2] = y0 + b; out[o + 3] = 255;
        out[o + 4] = y1 + r; out[o + 5] = y1 + g; out[o + 6] = y1 + b; out[o + 7] = 255;
      }
    } else for (let i = 0; i < src.length; i += 4) { out[i] = src[i + 2]; out[i + 1] = src[i + 1]; out[i + 2] = src[i]; out[i + 3] = 255; }
    return out;
  };
  api.onThumb(({ name, w, h, fmt, data }) => {
    requestAnimationFrame(() => api.thumbAck(name)); // ready for the next picture once this one is on screen
    const c = name === '\u0000replay' ? monitor : tiles.get(name); if (!c) return;
    if (c.canvas.width !== w || c.canvas.height !== h) { c.canvas.width = w; c.canvas.height = h; }
    c.canvas.getContext('2d').putImageData(new ImageData(toRgba(fmt, data, w, h), w, h), 0, 0);
    if (!c.pic) { c.pic = true; c.canvas.style.visibility = 'visible'; c.msg.textContent = ''; }
  });
  // meters: decibels from −60 to 0
  const lvl = (p) => (p > 0 ? Math.max(0, Math.min(1, (20 * Math.log10(p) + 60) / 60)) : 0);
  api.onLevels((levels) => { for (const [n, p] of Object.entries(levels)) { const c = tiles.get(n); if (c) { c.meters[0].style.setProperty('--l', lvl(p[0])); c.meters[1].style.setProperty('--l', lvl(p[1])); } } });
  api.onSources((list) => { all = list; drawSources(); });

  // ---------- replay ----------
  let rstate = st.replay;
  const monitor = { canvas: $('rCanvas'), msg: $('rMsg'), pic: false, el: $('rMon') };
  const R = (cmd, a) => api.replay(cmd, a).then((r) => { if (r && r.ok === false && r.error) toast(r.error, true); return r; });
  const chooseAngle = (name) => (ISO ? null : R('angle', { name }));
  const clockOf = (ms) => new Date(ms).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const secs = (x) => (x >= 60 ? `${Math.floor(x / 60)}:${pad(Math.floor(x % 60))}` : `${x.toFixed(1)}s`);
  function drawReplay() {
    const r = rstate;
    if (!r) return;
    const rp = r.mode === 'replay';
    $('replay').classList.toggle('on', rp);
    $('rMode').textContent = rp ? (r.playing ? `Replay ▶ ${Math.round(r.speed * 100)}%` : 'Replay ❚❚ cued') : 'Live';
    $('rMode').className = `mode ${rp ? 'rp' : 'live'}`;
    $('rOut').classList.toggle('on', r.enabled && r.connections > 0);
    $('rOutTxt').textContent = !r.enabled ? 'NDI out off' : `NDI out${r.connections ? ` · ${r.connections} watching` : ''}`;
    $('rOut').title = r.enabled ? `On the network as “${st.host} (${r.name})”${r.connections ? `, ${r.connections} watching` : ', no one watching yet'}. Click for Replay settings.` : 'The replay isn’t being sent out. Click to switch it on in Replay settings.';
    // the monitor
    const a = split(r.angle || '');
    $('rAngle').textContent = r.angle ? `${(r.angles.indexOf(r.angle) + 1) || ''} ${a.src}`.trim() : '';
    $('rSpd').textContent = rp ? (r.playing ? `${Math.round(r.speed * 100)}%` : 'PAUSED') : 'LIVE';
    $('rSpd').className = `spd ${rp ? (r.playing ? 'play' : 'paused') : 'live'}`;
    $('rTc').textContent = rp ? r.tc : '';
    $('rAgo').textContent = rp ? (r.take && !r.take.ended ? `${secs(Math.max(0, (Date.now() - r.pos) / 1000))} behind live` : `${hms((r.pos - r.first) / 1000)} into the take`) : '';
    if (!monitor.pic) monitor.msg.textContent = !r.angle ? 'Tick a source to see it here' : rp ? 'Reading the recording…' : 'Waiting for a picture…';
    // the scrub bar: the take from its start to the edge, with markers, clips, in/out and where the replay is
    const span = Math.max(1, r.edge - r.first), at = (ms) => `${Math.max(0, Math.min(100, ((ms - r.first) / span) * 100))}%`;
    $('rScrub').classList.toggle('off', !rp);
    $('rHead').style.left = at(r.pos);
    $('rStart').textContent = rp ? clockOf(r.first) : r.canReplay ? 'Cue a replay to scrub through the take' : 'Record to replay';
    $('rEnd').textContent = rp ? (r.take?.ended ? clockOf(r.edge) : 'live −3s') : '';
    const mk = rp ? r.markers.filter((m) => m.at >= r.first).map((m) => `<i style="left:${at(m.at)}" title="${esc(m.label)}" data-mk="${m.n}"></i>`).join('') : '';
    if ($('rMks').dataset.h !== mk) { $('rMks').innerHTML = mk; $('rMks').dataset.h = mk; }
    const cb = rp ? r.clips.map((c) => `<i style="left:${at(c.in)};width:calc(${at(c.out)} - ${at(c.in)})"></i>`).join('') : '';
    if ($('rClipBar').dataset.h !== cb) { $('rClipBar').innerHTML = cb; $('rClipBar').dataset.h = cb; }
    const io = rp && (r.inAt != null || r.outAt != null) ? `${r.inAt != null ? `<b class="in" style="left:${at(r.inAt)}"></b>` : ''}${r.outAt != null ? `<b class="out" style="left:${at(r.outAt)}"></b>` : ''}${r.inAt != null && r.outAt != null ? `<i style="left:${at(r.inAt)};width:calc(${at(r.outAt)} - ${at(r.inAt)})"></i>` : ''}` : '';
    if ($('rInOut').dataset.h !== io) { $('rInOut').innerHTML = io; $('rInOut').dataset.h = io; }
    // buttons
    const can = r.canReplay || rp;
    for (const b of document.querySelectorAll('.cue')) b.disabled = !r.canReplay;
    $('rCueMk').disabled = !r.canReplay || !r.markers.length;
    $('rLive').disabled = !rp;
    $('rLive').classList.toggle('lit', !rp);
    for (const id of ['rStepB', 'rStepF', 'rBack1s', 'rFwd1s', 'rIn', 'rOutPt', 'rSave']) $(id).disabled = !rp;
    $('rPlay').disabled = !can;
    $('rPlay').classList.toggle('playing', rp && r.playing);
    $('rPlayTxt').textContent = rp && r.playing ? 'PAUSE' : rp ? 'PLAY' : 'REPLAY';
    $('rPlay').title = rp ? 'Play / pause (Space)' : 'Replay the last 10 seconds (Space)';
    if (document.activeElement !== $('rSpeed')) $('rSpeed').value = Math.round(r.speed * 100);
    $('rSpeedVal').textContent = `${Math.round(r.speed * 100)}%`;
    for (const b of $('rPresets').children) b.classList.toggle('on', Math.abs(Number(b.dataset.spd) - r.speed * 100) < 0.5);
    $('rIn').classList.toggle('set', r.inAt != null); $('rOutPt').classList.toggle('set', r.outAt != null);
    // angles
    const ah = r.angles.map((n, i) => `<button type="button" data-angle="${esc(n)}" class="${n === r.angle ? 'on' : ''}" title="${esc(n)} (${i + 1})"><b>${i + 1}</b>${esc(split(n).src)}</button>`).join('') || '<span class="none">Tick sources to choose from</span>';
    if ($('rAngles').dataset.h !== ah) { $('rAngles').innerHTML = ah; $('rAngles').dataset.h = ah; }
    // clips
    const playingClip = r.playlist != null ? r.clips[r.playlist]?.n : r.clipEnd != null ? r.clips.find((c) => c.out === r.clipEnd)?.n : null;
    const ch = r.clips.map((c) => `<li class="${c.n === playingClip ? 'now' : ''}" data-n="${c.n}"><span class="n">${c.n}</span><span class="nm" title="Double-click to rename">${esc(c.label)}</span><span class="an">${esc(split(c.angle).src)}</span><span class="tc">${esc(c.tcIn)}</span><span class="len">${secs(c.secs)}</span><button type="button" class="cp" title="Play this clip">▶</button><button type="button" class="cx" title="Delete this clip">×</button></li>`).join('');
    if ($('rClips').dataset.h !== ch) { $('rClips').innerHTML = ch; $('rClips').dataset.h = ch; }
    $('rPlayAll').disabled = !r.clips.length;
    $('rClips').classList.toggle('empty', !r.clips.length);
    $('rClips').dataset.empty = rp ? 'Mark In (I) and Out (O) on a replay, then Save clip (C).' : 'Clips you save from replays are listed here.';
  }
  api.onReplay((r) => { const angleWas = rstate?.angle, modeWas = rstate?.mode; rstate = r; if (r.angle !== angleWas || r.mode !== modeWas) { monitor.pic = false; monitor.canvas.style.visibility = 'hidden'; drawSources(); } drawReplay(); });
  // the monitor's picture, as sharp as it's shown
  new ResizeObserver(() => { const px = Math.min(1280, Math.ceil(($('rMon').clientWidth * (window.devicePixelRatio || 1)) / 160) * 160); api.thumbSize('\u0000replay', px); }).observe($('rMon'));
  const cue = (seconds, play) => R('cue', { seconds, play });
  for (const b of document.querySelectorAll('.cue[data-cue]')) b.onclick = () => cue(Number(b.dataset.cue));
  const cueMarker = () => R('cue', { marker: 'last' });
  $('rCueMk').onclick = cueMarker;
  $('rLive').onclick = () => R('live');
  $('rPlay').onclick = () => R('toggle');
  $('rStepB').onclick = () => R('step', { frames: -1 }); $('rStepF').onclick = () => R('step', { frames: 1 });
  $('rBack1s').onclick = () => R('jump', { seconds: -1 }); $('rFwd1s').onclick = () => R('jump', { seconds: 1 });
  for (const b of $('rPresets').children) b.onclick = () => R('speed', { value: Number(b.dataset.spd) });
  $('rSpeed').oninput = () => { $('rSpeedVal').textContent = `${$('rSpeed').value}%`; R('speed', { value: Number($('rSpeed').value) }); };
  $('rAngles').onclick = (e) => { const b = e.target.closest('[data-angle]'); if (b) chooseAngle(b.dataset.angle); };
  $('rIn').onclick = () => R('in'); $('rOutPt').onclick = () => R('out');
  const saveClip = async () => { const r = await R('clip'); if (r?.ok) toast(`Saved clip ${r.clip.n} (${secs((r.clip.out - r.clip.in) / 1000)})`); };
  $('rSave').onclick = saveClip;
  $('rPlayAll').onclick = () => R('clip-play', { all: true });
  $('rClips').onclick = (e) => {
    const li = e.target.closest('li'); if (!li) return;
    const n = Number(li.dataset.n);
    if (e.target.closest('.cx')) { if (confirm(`Delete clip ${n}? (The recording isn’t touched.)`)) R('clip-delete', { n }); }
    else if (e.target.closest('.cp')) R('clip-play', { n });
  };
  $('rClips').ondblclick = (e) => {
    const nm = e.target.closest('.nm'); if (!nm) return;
    const li = nm.closest('li'), n = Number(li.dataset.n);
    const inp = document.createElement('input'); inp.value = nm.textContent; inp.maxLength = 80; nm.replaceWith(inp); inp.focus(); inp.select();
    const done = (save) => { if (save) R('clip-rename', { n, label: inp.value }); $('rClips').dataset.h = ''; drawReplay(); };
    inp.onkeydown = (k) => { if (k.key === 'Enter') done(true); if (k.key === 'Escape') done(false); k.stopPropagation(); };
    inp.onblur = () => done(true);
  };
  $('rMks').onclick = (e) => { const m = e.target.closest('[data-mk]'); if (m) { e.stopPropagation(); R('cue', { marker: Number(m.dataset.mk) }); } };
  // scrubbing: click or drag along the bar (pauses the replay)
  let scrubbing = false;
  const scrubTo = (e) => {
    const r = rstate; if (!r || r.mode !== 'replay') return;
    const b = $('rScrub').querySelector('.track').getBoundingClientRect(), f = Math.max(0, Math.min(1, (e.clientX - b.left) / b.width));
    R('seek', { at: r.first + f * (r.edge - r.first) });
  };
  $('rScrub').addEventListener('pointerdown', (e) => { if (rstate?.mode !== 'replay' || e.target.closest('[data-mk]')) return; scrubbing = true; $('rScrub').setPointerCapture(e.pointerId); if (rstate.playing) R('pause'); scrubTo(e); });
  $('rScrub').addEventListener('pointermove', (e) => { if (scrubbing) scrubTo(e); });
  $('rScrub').addEventListener('pointerup', () => { scrubbing = false; });
  $('rOut').onclick = () => openSettings('replay');
  // the REPLAY tag for the output, drawn here with the app's font, at the size for a 1080 picture
  async function sendTag() {
    try { await document.fonts.load('800 40px "SC Sora"'); } catch {}
    // (drawn big; the app scales it down to 6% of the picture's height)
    const k = 3, c = document.createElement('canvas'), x = c.getContext('2d'), h = 64 * k, font = `800 ${34 * k}px "SC Sora", "SC Inter", sans-serif`;
    x.font = font; const tw = Math.ceil(x.measureText('REPLAY').width);
    c.width = tw + (22 + 26 + 22) * k; c.height = h;
    x.font = font;
    x.fillStyle = 'rgba(10,10,12,0.82)'; x.beginPath(); x.roundRect(0, 0, c.width, h, 8 * k); x.fill();
    x.fillStyle = '#ff3b3f'; x.beginPath(); x.arc((22 + 9) * k, h / 2, 9 * k, 0, Math.PI * 2); x.fill();
    x.fillStyle = '#ffffff'; x.textBaseline = 'middle'; x.fillText('REPLAY', (22 + 26) * k, h / 2 + 2 * k);
    const img = x.getImageData(0, 0, c.width, h);
    api.replay('tag-image', { img: { w: c.width, h, data: img.data } });
  }
  if (!ISO) sendTag();
  // ---------- demo mode ----------
  const setDemo = async (on) => {
    if (recording()) return toast('Stop recording first.', true);
    cfg = await api.settings({ demo: on }); drawDemo(); drawSources();
    if (on) toast(ISO ? 'Demo mode: three practice cameras. Press REC to try recording.' : 'Demo mode: three practice cameras. Press REC, then W to replay.');
  };
  function drawDemo() { $('demoPill').hidden = !cfg.demo; $('sDemo').checked = !!cfg.demo; }
  document.addEventListener('click', (e) => { if (e.target.closest('[data-demo]')) setDemo(true); });
  $('demoPill').onclick = () => setDemo(false);
  $('sDemo').onchange = () => setDemo($('sDemo').checked);
  function drawReplaySettings() {
    const r = rstate || {};
    drawDemo(); $('sDemo').disabled = recording();
    $('sROut').checked = cfg.replayOut !== false; $('sRTag').checked = cfg.replayTag !== false; $('sPreroll').value = cfg.preroll ?? 3;
    $('sROutNote').textContent = st.ndi.ok ? `On the network as “${st.host} (${r.name || 'Showcaller Replay'})”: add it to a switcher, OBS or vMix like any other NDI source.` : 'NDI isn’t running on this computer, so the replay can’t be sent out.';
    $('sCtl').checked = !!cfg.control; $('sCtlPort').value = cfg.controlPort || 4780;
    drawControl();
  }
  let control = st.control || {};
  function drawControl() {
    const host = (st.addresses && st.addresses[0]) || 'localhost', port = cfg.controlPort || 4780, base = `http://${host}:${port}/api`;
    $('sCtlSt').className = `status ${control.on ? 'ok' : control.error ? 'bad' : ''}`;
    $('sCtlSt').textContent = control.on ? `On, at ${(st.addresses || []).map((a) => `${a}:${port}`).join(', ') || `port ${port}`}.` : control.error || 'Off.';
    $('sCtlUrls').textContent = (ISO ? [
      `${base}/record                start recording`,
      `${base}/stop                  stop recording`,
      `${base}/mark?label=Goal       add a marker`,
      `${base}/state                 what's happening, as JSON`,
    ] : [
      `${base}/cue?seconds=10        cue 10 seconds back (add &play=1 to play at once)`,
      `${base}/cue?marker=last       cue the last marker`,
      `${base}/toggle                play / pause`,
      `${base}/speed?value=50        speed in % (or /speed/up, /speed/down)`,
      `${base}/angle?n=2             angle 2`,
      `${base}/step?frames=-1        a frame back`,
      `${base}/live                  back to live`,
      `${base}/in   /out   /clip     mark in, mark out, save the clip`,
      `${base}/clips/play?all=1      play all the clips`,
      `${base}/record   /stop   /mark?label=Goal`,
      `${base}/state                 what's happening, as JSON`,
    ]).join('\n');
  }
  api.onControl((c) => { control = c; drawControl(); });
  $('sROut').onchange = async () => { cfg = await api.settings({ replayOut: $('sROut').checked }); };
  $('sRTag').onchange = async () => { cfg = await api.settings({ replayTag: $('sRTag').checked }); };
  $('sPreroll').onchange = async () => { cfg = await api.settings({ preroll: Number($('sPreroll').value) }); $('sPreroll').value = cfg.preroll; };
  $('sCtl').onchange = async () => { cfg = await api.settings({ control: $('sCtl').checked }); drawControl(); };
  $('sCtlPort').onchange = async () => { cfg = await api.settings({ controlPort: Number($('sCtlPort').value) }); $('sCtlPort').value = cfg.controlPort; drawControl(); };

  // ---------- recording ----------
  function drawRec() {
    const t = status?.take, rec = !!t, stopping = !!status?.stopping, locked = !cfg.pro?.ok;
    $('recState').classList.toggle('on', rec);
    $('recLbl').textContent = stopping ? 'Finishing' : rec ? 'Rec' : 'Standby';
    $('recTime').textContent = hms(t?.seconds || 0);
    $('recTc').textContent = t ? `TC ${t.tc}  ·  ${t.tracks.length} angle${t.tracks.length > 1 ? 's' : ''}` : `TC --:--:--:--  ·  ${cfg.sources.length} ticked`;
    if (ISO) {
      $('isoTop').className = `isotop ionly${rec ? ' on' : ''}${stopping ? ' saving' : ''}`;
      $('iLbl').textContent = stopping ? 'Saving' : rec ? 'Recording' : 'Standby';
      $('iTime').textContent = hms(t?.seconds || 0);
      $('iSub').textContent = t ? `TC ${t.tc}  ·  ${t.folder}` : status?.lastTake ? `Last take: ${status.lastTake.folder}` : cfg.sources.length ? `Ready to record ${cfg.sources.length} source${cfg.sources.length === 1 ? '' : 's'}` : 'Add a source to record';
      $('iSrc').textContent = t ? `${t.tracks.filter((x) => x.recording && !x.missing).length} / ${t.tracks.length}` : String(cfg.sources.length);
      $('iBytes').textContent = gb(t?.bytes || 0);
      $('iRate').textContent = t?.rate ? `${(t.rate / 1e6).toFixed(1)} MB/s` : '–';
      $('iMarks').textContent = String(t?.markers?.length || 0);
    }
    $('recBtn').classList.toggle('on', rec);
    $('recBtnTxt').textContent = stopping ? 'SAVING' : 'REC';
    $('recBtn').disabled = rec || stopping || locked || !cfg.sources.length;
    $('recBtn').title = locked ? 'Recording needs a license key' : !cfg.sources.length ? 'Tick a source first' : `Record (${mac ? '⌘R' : 'Ctrl+R'})`;
    $('stopBtn').disabled = !rec || stopping;
    $('markBtn').disabled = !rec;
    for (const id of ['codecSel', 'folderBtn']) $(id).disabled = rec;
    // disk
    const d = status?.disk;
    if (d) {
      const left = status.secondsLeft;
      $('diskTxt').textContent = `${gb(d.free)} free`;
      $('diskLeft').textContent = rec && left ? `≈ ${hoursMins(left)} left` : '';
      $('diskBar').style.width = `${d.total ? Math.max(1, Math.min(100, (100 * (d.total - d.free)) / d.total)) : 0}%`;
      $('diskPill').title = `Recording drive: ${gb(d.free)} free of ${gb(d.total)}`;
      $('diskPill').className = `disk ${d.free < 5e9 || (left && left < 600) ? 'bad' : d.free < 50e9 || (left && left < 3600) ? 'warn' : ''}`;
    } else { $('diskTxt').textContent = 'Drive not found'; $('diskLeft').textContent = ''; }
    // markers
    const ms = t?.markers || [];
    const mk = ms.slice().reverse().map((m) => `<li title="${esc(m.label)} · ${esc(m.tc)}"><span class="n">${m.n}</span><span class="t">${esc(m.time.slice(0, 8))}</span><span class="l">${esc(m.label)}</span></li>`).join('');
    if ($('marks').dataset.html !== mk) { $('marks').innerHTML = mk; $('marks').dataset.html = mk; }
    // footer summary
    const lt = status?.lastTake;
    if (rec) {
      const n = t.tracks.filter((x) => x.recording).length;
      $('summary').innerHTML = `<b>${n} of ${t.tracks.length}</b> source${t.tracks.length > 1 ? 's' : ''} recording into <b>${esc(t.folder)}</b> · ${gb(t.bytes || 0)}`;
    } else if (stopping) $('summary').textContent = 'Finishing the files…';
    else if (lt) {
      $('summary').innerHTML = `Saved <b>${esc(lt.folder)}</b>: ${lt.files} file${lt.files === 1 ? '' : 's'}, ${hms(lt.seconds)}, ${gb(lt.bytes)}${lt.markers ? `, ${lt.markers} marker${lt.markers > 1 ? 's' : ''}` : ''}${lt.problems.length ? ` · <span style="color:#ff8b8b">check ${esc(lt.problems.join(', '))}</span>` : ''} · <a id="openLast">Show the files</a>`;
      $('openLast').onclick = () => api.openFolder(lt.dir);
    } else $('summary').textContent = '';
    drawSources();
  }
  async function start() {
    if (recording()) return;
    $('recBtn').disabled = true;
    await api.settings({ takeName: $('takeName').value });
    const r = await api.start();
    if (!r.ok) { toast(r.error || 'Couldn’t start recording.', true); drawRec(); return; }
    $('marks').innerHTML = '';
  }
  async function stop() {
    if (!recording()) return;
    if (!confirm('Stop recording? The files are finished and saved.')) return;
    const r = await api.stop();
    if (r?.ok) { toast(`Saved ${r.files} file${r.files === 1 ? '' : 's'} in ${r.folder}`); $('takeName').value = ''; api.settings({ takeName: '' }); }
  }
  async function mark() {
    if (!recording()) return;
    const m = await api.mark($('markLabel').value);
    if (m) { $('markLabel').value = ''; toast(`Marker ${m.n} at ${m.time.slice(0, 8)}`); status.take.markers = [...(status.take.markers || []), m]; drawRec(); }
  }
  $('recBtn').onclick = start;
  $('stopBtn').onclick = stop;
  $('markBtn').onclick = mark;
  // Return adds the marker and leaves the box, so the replay keys work again straight away (Esc just leaves it)
  $('markLabel').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); mark(); $('markLabel').blur(); } else if (e.key === 'Escape') $('markLabel').blur(); });
  $('takeName').addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === 'Escape') $('takeName').blur(); });
  api.onStatus((s) => { status = s; drawRec(); });

  // messages from the recording
  function logLine(n) {
    const li = document.createElement('li');
    li.className = n.kind || 'warn';
    li.innerHTML = `<time>${new Date(n.at || Date.now()).toLocaleTimeString()}</time>${esc(n.text)}`;
    $('log').prepend(li); $('logCard').hidden = false;
    while ($('log').children.length > 30) $('log').lastChild.remove();
  }
  (st.notices || []).forEach(logLine);
  api.onNotice((n) => { logLine(n); if (n.kind === 'bad') toast(n.text, true); });
  $('logClear').onclick = () => { $('log').innerHTML = ''; $('logCard').hidden = true; };

  // ---------- next take ----------
  $('takeName').value = cfg.takeName || '';
  $('takeName').addEventListener('change', () => api.settings({ takeName: $('takeName').value }));
  const setCodec = async (v) => { cfg = await api.settings({ codec: v }); fillCodecs(); };
  $('codecSel').onchange = () => setCodec($('codecSel').value);
  $('sCodec').onchange = () => setCodec($('sCodec').value);
  function drawFolder() { const parts = cfg.folder.split(/[\\/]/).filter(Boolean); $('folderTxt').textContent = parts.length > 2 ? `…/${parts.slice(-2).join('/')}` : cfg.folder; $('folderBtn').title = `${cfg.folder}\nClick to choose another folder`; $('sFolder').value = cfg.folder; }
  const pick = async () => { const r = await api.pickFolder(); if (r.ok) { cfg.folder = r.folder; drawFolder(); } };
  $('folderBtn').onclick = pick; $('sFolderBtn').onclick = pick;
  $('openBtn').onclick = () => api.openFolder(status?.take?.dir || '');

  // ---------- license ----------
  function drawPro() {
    const p = cfg.pro || {};
    $('licBox').className = `licbox ${p.licensed ? 'ok' : p.trial ? 'warn' : 'bad'}`;
    $('licBox').innerHTML = p.licensed
      ? `<b class="big">${NAME} is unlocked</b><span>Licensed to ${esc(p.to)}${p.exp ? `, until ${esc(p.exp)}` : ''}.</span>`
      : p.trial ? `<b class="big">Free trial: ${p.daysLeft} ${p.daysLeft === 1 ? 'day' : 'days'} left</b><span>Add a Showcaller Studio license key to keep recording after that.</span>`
        : ISO ? '<b class="big">Recording is locked</b><span>The free trial has ended. Add a Showcaller Studio license key to record.</span>'
          : '<b class="big">Recording and replay are locked</b><span>The free trial has ended. Add a Showcaller Studio license key to record and replay.</span>';
    $('sLicRemove').hidden = !p.licensed;
    $('lockBanner').hidden = !!p.ok;
    $('trialPill').hidden = !(p.trial && !p.licensed);
    $('trialPill').textContent = `Trial: ${p.daysLeft} ${p.daysLeft === 1 ? 'day' : 'days'} left`;
  }
  const licMsg = (t, ok) => { $('sLicMsg').textContent = t || ''; $('sLicMsg').className = `msgline ${ok ? 'ok' : t ? 'bad' : ''}`; };
  $('sLicBtn').onclick = async () => {
    const key = $('sLicKey').value.trim();
    if (!key) return licMsg('Paste your Showcaller Studio license key first.');
    const r = await api.license(key);
    if (r.error && !r.licensed) return licMsg(r.error);
    cfg.pro = r; $('sLicKey').value = ''; licMsg(''); drawPro(); drawRec(); toast(`${NAME} unlocked`);
  };
  $('sLicRemove').onclick = async () => {
    if (!confirm('Remove the license key from this computer? Recording stops working here until a key is added again.')) return;
    cfg.pro = await api.license(''); licMsg(''); drawPro(); drawRec();
  };
  $('sLicBuy').onclick = () => api.buy();
  const openLicense = () => { setWin.open('license'); setTimeout(() => $('sLicKey').focus(), 0); };
  $('lockBtn').onclick = openLicense; $('trialPill').onclick = openLicense;

  // ---------- NDI ----------
  function drawNdi() {
    const n = st.ndi;
    $('sNdiSt').className = `status ${n.ok ? 'ok' : 'bad'}`;
    $('sNdiSt').innerHTML = n.ok ? `NDI is running${n.version ? ` (${esc(n.version.replace(/^NDI SDK\s*/i, ''))})` : ''}${n.builtIn ? ', built into the app' : ''}. ${all.length} source${all.length === 1 ? '' : 's'} found.` : esc(n.reason);
    $('ndiBanner').hidden = n.ok;
    $('ndiBannerTxt').textContent = n.reason || '';
    $('ndiBannerBtn').hidden = !n.needsRuntime;
  }
  $('ndiBannerBtn').onclick = () => api.openLink(st.ndi.link);
  $('sNdiRefresh').onclick = () => { api.ndiRefresh(); toast('Looking for NDI sources again'); };
  $('sExtraIps').value = cfg.extraIps || '';
  $('sExtraIps').addEventListener('change', async () => { cfg = await api.settings({ extraIps: $('sExtraIps').value }); $('sExtraIps').value = cfg.extraIps; });

  // ---------- settings window ----------
  const setWin = SCSettings($('settings'), { key: 'iso.setPane', first: 'recording' });
  const openSettings = (pane) => { drawFolder(); fillCodecs(); drawNdi(); drawPro(); licMsg(''); drawReplaySettings(); $('sCodec').disabled = recording(); $('sFolderBtn').disabled = recording(); setWin.open(pane); };
  $('setBtn').onclick = () => openSettings();
  document.addEventListener('click', (e) => {
    const l = e.target.closest('[data-link]'); if (l) { e.preventDefault(); api.openLink(l.dataset.link); }
    const o = e.target.closest('[data-open]'); if (o) { e.preventDefault(); openSettings(o.dataset.open); }
  });

  // ---------- keys and menu ----------
  const typing = (e) => /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) && e.target.type !== 'checkbox';
  document.addEventListener('keydown', (e) => {
    if (!$('settings').hidden) { if (e.key === 'Escape') setWin.close(); return; }
    if (typing(e) || e.metaKey || e.ctrlKey || e.altKey) return;
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    const act = ISO ? { m: mark }[k] : {
      m: mark, q: () => cue(5), w: () => cue(10), e: () => cue(30), r: cueMarker, ' ': () => R('toggle'),
      l: () => R('live'), Escape: () => R('live'), i: () => R('in'), o: () => R('out'), c: saveClip, p: () => R('clip-play', { all: true }),
      ArrowLeft: () => (e.shiftKey ? R('jump', { seconds: -1 }) : R('step', { frames: -1 })), ArrowRight: () => (e.shiftKey ? R('jump', { seconds: 1 }) : R('step', { frames: 1 })),
      ArrowUp: () => R('faster'), ArrowDown: () => R('slower'),
    }[k] || (/^[1-9]$/.test(k) ? () => { const n = rstate?.angles[Number(k) - 1]; if (n) chooseAngle(n); } : null);
    if (act) { e.preventDefault(); act(); }
  });
  api.onCommand((c) => ({ settings: () => openSettings(), record: start, stop, mark, folder: pick, license: openLicense,
    cue5: () => cue(5), cue10: () => cue(10), cue30: () => cue(30), cueMarker, toggle: () => R('toggle'), slower: () => R('slower'), faster: () => R('faster'),
    live: () => R('live'), in: () => R('in'), out: () => R('out'), clip: saveClip, playAll: () => R('clip-play', { all: true }) }[c]?.()));
  api.onCfg((c) => { cfg = c; drawDemo(); drawPro(); fillCodecs(); drawFolder(); drawRec(); if (!$('settings').hidden) drawNdi(); });
  api.onEncoders((e) => { encoders = e; encodersReady = true; fillCodecs(); });
  api.onUpdate((u) => { $('updBtn').hidden = !u; if (u) { $('updBtn').textContent = `Update ${u.version}`; $('updBtn').onclick = () => api.openLink(u.page); } });

  fillCodecs(); drawFolder(); drawPro(); drawNdi(); drawRec(); drawReplay(); drawDemo();
  setInterval(() => { drawSources(); drawReplay(); }, 1000); // "Connecting…" / "Not on the network" as time passes
  window.__iso = { openSettings, toast }; // for screenshots
})();
