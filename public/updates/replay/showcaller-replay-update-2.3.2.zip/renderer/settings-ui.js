// Showcaller apps: the Settings window, the same in every app (taken from Showcaller Studio's Settings).
// Keep this file identical in every app. Markup: .scset > .scset-dlg > .dlg-head / .setwrap (.setnav + .setbody) / .dlg-foot.
// SCSettings(el, { key, first, onClose }) → { open(pane?), close(), show(pane), pane }
(function () {
  const ICONS = {
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
    key: '<circle cx="8" cy="15" r="4.2"/><path d="m11.2 12 8.3-8.3M16 7.2l2.6 2.6M13.6 9.6l2 2"/>',
    lock: '<rect x="4.5" y="10.5" width="15" height="10" rx="2"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/>',
    timer: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 9.5v4l2.5 2M9.5 3h5M12 3v3"/>',
    monitor: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8.5 20h7M12 16v4"/>',
    video: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10.5 5-3v9l-5-3"/>',
    keyboard: '<rect x="2.5" y="6" width="19" height="12" rx="2"/><path d="M6.5 10h.01M10 10h.01M13.5 10h.01M17 10h.01M7.5 14h9"/>',
    live: '<circle cx="12" cy="12" r="2"/><path d="M8.2 8.2a5.4 5.4 0 0 0 0 7.6M15.8 15.8a5.4 5.4 0 0 0 0-7.6M5.3 5.3a9.5 9.5 0 0 0 0 13.4M18.7 18.7a9.5 9.5 0 0 0 0-13.4"/>',
    speaker: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
    grid: '<rect x="3" y="4" width="8" height="7" rx="1.2"/><rect x="13" y="4" width="8" height="7" rx="1.2"/><rect x="3" y="13" width="8" height="7" rx="1.2"/><rect x="13" y="13" width="8" height="7" rx="1.2"/>',
    shield: '<path d="M12 3 4.5 6v5.5c0 4.6 3.2 8.4 7.5 9.5 4.3-1.1 7.5-4.9 7.5-9.5V6z"/><path d="m8.8 12 2.2 2.2 4.4-4.6"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.66 0l3-3a4 4 0 0 0-5.66-5.66l-1 1"/><path d="M14 10a4 4 0 0 0-5.66 0l-3 3a4 4 0 0 0 5.66 5.66l1-1"/>',
    computers: '<rect x="2" y="4" width="11" height="8" rx="1.5"/><rect x="11" y="10" width="11" height="8" rx="1.5"/><path d="M5 15h4M15 21h4"/>',
    sliders: '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.6 9.3a2.5 2.5 0 0 1 4.8.9c0 1.7-2.4 2.2-2.4 3.8M12 17h.01"/>',
  };
  if (!document.getElementById('sc-icons')) {
    const d = document.createElement('div');
    d.innerHTML = `<svg id="sc-icons" width="0" height="0" style="position:absolute" aria-hidden="true">${Object.entries(ICONS).map(([k, v]) => `<symbol id="i-${k}" viewBox="0 0 24 24">${v}</symbol>`).join('')}</svg>`;
    document.body.prepend(d.firstChild);
  }
  window.SCSettings = function (el, { key = 'sc.setPane', first, onClose } = {}) {
    const body = el.querySelector('.setbody'), search = el.querySelector('.setsearch input'), none = el.querySelector('.setnone');
    const panes = () => [...el.querySelectorAll('.setpane')], navs = () => [...el.querySelectorAll('.setnav-btn')];
    let pane = first || panes()[0]?.dataset.pane;
    try { pane = localStorage.getItem(key) || pane; } catch {}
    function show(k) {
      if (!el.querySelector(`.setpane[data-pane="${k}"]`)) k = first || panes()[0]?.dataset.pane;
      pane = k; try { localStorage.setItem(key, k); } catch {}
      if (search) search.value = '';
      body.classList.remove('searching'); if (none) none.hidden = true;
      panes().forEach((p) => p.classList.toggle('show', p.dataset.pane === k));
      navs().forEach((b) => { b.classList.toggle('on', b.dataset.pane === k); b.classList.remove('dim'); });
      body.scrollTop = 0;
    }
    el.querySelector('.setnav').addEventListener('click', (e) => { const b = e.target.closest('.setnav-btn'); if (b) show(b.dataset.pane); });
    el.addEventListener('click', (e) => { const a = e.target.closest('[data-pane-link]'); if (a) { e.preventDefault(); show(a.dataset.paneLink); } });
    // Search: show every page that mentions the words (labels, hints and choices).
    search?.addEventListener('input', () => {
      const q = search.value.trim().toLowerCase();
      if (!q) return show(pane);
      body.classList.add('searching');
      const words = q.split(/\s+/); let any = false;
      panes().forEach((p) => {
        const txt = (p.textContent + ' ' + [...p.querySelectorAll('option')].map((o) => o.textContent).join(' ')).toLowerCase();
        const hit = words.every((w) => txt.includes(w));
        p.classList.toggle('show', hit); any ||= hit;
        const b = el.querySelector(`.setnav-btn[data-pane="${p.dataset.pane}"]`);
        if (b) { b.classList.toggle('dim', !hit); b.classList.remove('on'); }
      });
      if (none) none.hidden = any;
    });
    search?.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && search.value) { e.preventDefault(); e.stopPropagation(); show(pane); }
      if (e.key === 'Enter') { e.preventDefault(); const f = el.querySelector('.setpane.show'); if (f) show(f.dataset.pane); }
    });
    const close = () => { if (el.hidden) return; if (onClose && onClose() === false) return; el.hidden = true; };
    el.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', close));
    el.addEventListener('mousedown', (e) => { if (e.target === el) close(); });
    return {
      open(k) { show(typeof k === 'string' ? k : pane); el.hidden = false; },
      close, show, get pane() { return pane; },
    };
  };
})();
