// Replay for Showcaller Replay: plays back what's being recorded, from any angle, at any speed, out as an NDI source.
//
// The recordings are the replay store. Each source's .mov is written half a second at a time, so it can be read
// while it's still recording: an FFmpeg reads it from the cued moment and hands back raw pictures (UYVY, what NDI
// sends) and sound. An FFmpeg only sees as much of the file as there was when it opened it, so near the live edge
// a new one picks up where the last stopped.
//
// The output runs on its own clock at the angle's frame rate. Slow motion shows each picture for longer (so below
// about 50% it steps, like any replay from normal-speed cameras), and sound is only sent at 100%. When nothing is
// being replayed, the output passes the chosen angle through live.
const { spawn } = require('child_process');
const { EventEmitter } = require('events');
const fs = require('fs');
const path = require('path');
const { todTimecode, timecode } = require('./recorder');
// (FFmpeg's info output carries each picture's timestamp; see Reader)

const RATE = 48000;
const EDGE_MS = 3000; // how close to live replay can play
const READ_EDGE_MS = 1500; // how close to live the files are read (what has surely been written to them by now)
const AHEAD = 8; // pictures read ahead
const HISTORY_BYTES = 160e6; // recent pictures kept for stepping backwards without reading the file again

// ---------- reading a recording ----------
// Pictures `first` to `last` (counted from the start of the file; `last` is Infinity to read to the end). While a file
// is recording, `last` is what has surely been written by now, and the next Reader is started ahead of time to carry on
// from there, so playing near live doesn't stutter while a new one gets going.
class Reader {
  constructor(bin, part, first, last = Infinity) {
    Object.assign(this, { part, first, last, next: first, q: [], ended: false, failed: '', started: Date.now() });
    if (process.env.RP_DEBUG) console.log('reader', path.basename(part.file), first, last, Date.now() % 100000);
    this.fb = part.w * part.h * 2; this.cur = null; this.off = 0;
    this.spf = (RATE * part.D) / part.N; // sound samples per picture
    this.audio = []; this.aFrom = 0; // sound waiting, and the sample (from `ss`) it starts at
    // Each picture's number comes from its own timestamp (FFmpeg's showinfo, on the error output), not from counting:
    // that's exact even where a seek lands a picture early or the file is missing one.
    this.pending = []; this.pts = []; this.tb = null;
    this.ss = Math.max(0, ((first - 0.5) * part.D) / part.N); // half a picture early, so `first` is surely in
    const args = ['-hide_banner', '-loglevel', 'info', '-nostats', ...(this.ss > 0 ? ['-ss', this.ss.toFixed(6)] : []), '-copyts', '-i', part.file,
      '-map', '0:v:0', '-vf', 'showinfo=checksum=0', '-fps_mode', 'passthrough', '-f', 'rawvideo', '-pix_fmt', 'uyvy422', 'pipe:1',
      '-map', '0:a:0', '-f', 'f32le', '-ar', String(RATE), '-ac', '2', 'pipe:3'];
    try { this.proc = spawn(bin, args, { stdio: ['ignore', 'pipe', 'pipe', 'pipe'], windowsHide: true }); }
    catch (e) { this.ended = true; this.failed = e.message; return; }
    const p = this.proc;
    p.stdout.on('data', (d) => this.onVideo(d));
    p.stdio[3].on('data', (d) => this.audio.push(d));
    let line = '';
    p.stderr.on('data', (d) => {
      const lines = (line + d).split('\n'); line = lines.pop();
      for (const l of lines) {
        let m;
        if ((m = /time_base:\s*(\d+)\/(\d+)/.exec(l)) && !this.tb) this.tb = [Number(m[1]), Number(m[2])];
        else if ((m = /\sn:\s*\d+\s+pts:\s*(-?\d+)/.exec(l))) { this.pts.push(Number(m[1])); this.place(); }
        else if (/error|invalid|no such/i.test(l)) this.failed = l.replace(/^\[[^\]]*\]\s*/, '').slice(0, 200);
      }
    });
    for (const s of [p.stdout, p.stdio[3]]) s.on('error', () => {});
    p.on('error', (e) => { this.failed = e.message; this.ended = true; });
    p.on('close', () => { this.ended = true; });
  }
  onVideo(d) {
    let i = 0;
    while (i < d.length) {
      if (!this.cur) { this.cur = Buffer.allocUnsafe(this.fb); this.off = 0; }
      const n = Math.min(d.length - i, this.fb - this.off);
      d.copy(this.cur, this.off, i, i + n); this.off += n; i += n;
      if (this.off === this.fb) { this.pending.push(this.cur); this.cur = null; }
    }
    this.place();
  }
  // pictures and their timestamps, paired up in order
  place() {
    while (this.pending.length && this.pts.length && this.tb && !this.stopped) {
      const data = this.pending.shift(), pts = this.pts.shift();
      const idx = Math.round((pts * this.tb[0] * this.part.N) / (this.tb[1] * this.part.D));
      if (idx < this.first) continue; // (before the one asked for)
      if (idx > this.last) { this.stop(); return; } // read as far as it was asked to
      this.q.push({ idx, data }); this.next = idx + 1;
    }
    if (this.q.length >= AHEAD && !this.paused) { this.paused = true; this.proc.stdout.pause(); }
  }
  get done() { return this.ended || this.next > this.last; }
  stop() { this.stopped = true; this.ended = true; this.cur = null; try { this.proc?.kill('SIGKILL'); } catch {} }
  resume() { if (this.paused && this.q.length < AHEAD / 2 && !this.ended) { this.paused = false; this.proc.stdout.resume(); } }
  get low() { return this.q.length ? this.q[0].idx : this.next; } // the earliest picture it can still give
  // The picture for `idx` (or, where the file has none with that number, the one before it), letting go of the
  // ones before (returned in `gone`, for the history). Null while it's still to come.
  take(idx, gone) {
    while (this.q.length > 1 && this.q[1].idx <= idx) gone.push(this.q.shift());
    this.resume();
    const f = this.q[0];
    if (!f) return null;
    if (f.idx === idx || (f.idx < idx && (this.q.length > 1 || this.done))) return f;
    if (f.idx > idx && f.idx - idx <= 2) return f; // (a seek that landed just after)
    return null;
  }
  // The sound that goes with picture `idx`, as planar float (left then right); short of sound, silence.
  sound(idx) {
    const at = (k) => Math.round(((k * this.part.D) / this.part.N - this.ss) * RATE);
    const from = at(idx), n = at(idx + 1) - from;
    const out = new Float32Array(Math.max(0, n) * 2);
    if (n <= 0) return { data: out, n: 0 };
    if (from > this.aFrom) this.pull((from - this.aFrom) * 8);
    const inter = this.pull(n * 8), k = Math.floor(inter.length / 8); // interleaved stereo, 8 bytes a sample
    for (let s = 0; s < k; s++) { out[s] = inter.readFloatLE(s * 8); out[n + s] = inter.readFloatLE(s * 8 + 4); }
    return { data: out, n };
  }
  pull(bytes) {
    const parts = []; let got = 0;
    while (got < bytes && this.audio.length) {
      const b = this.audio[0], need = bytes - got;
      if (b.length <= need) { parts.push(b); got += b.length; this.audio.shift(); }
      else { parts.push(b.subarray(0, need)); this.audio[0] = b.subarray(need); got += need; }
    }
    this.aFrom += Math.floor(got / 8);
    return parts.length === 1 ? parts[0] : Buffer.concat(parts, got);
  }
  close() { this.ended = true; try { this.proc?.kill('SIGKILL'); } catch {} this.q = []; this.audio = []; }
}

// ---------- the REPLAY tag in the corner ----------
// The window draws it (with the app's font) and hands it over as RGBA; here it's turned into what's added to a UYVY
// picture, at the size that suits each picture size.
function tagFor(src, h) {
  if (!src) return null;
  // 6% of the picture's height, scaled down by averaging (so the lettering stays clean at any size)
  const th = Math.max(8, Math.round(h * 0.06)), scale = th / src.h, w = Math.max(2, Math.round((src.w * scale) / 2) * 2);
  const Y = new Uint8Array(w * th), U = new Uint8Array((w / 2) * th), V = new Uint8Array((w / 2) * th), A = new Float32Array(w * th);
  const R = new Float32Array(w * th), G = new Float32Array(w * th), B = new Float32Array(w * th);
  for (let y = 0; y < th; y++) for (let x = 0; x < w; x++) {
    const sx0 = Math.floor(x / scale), sx1 = Math.max(sx0 + 1, Math.min(src.w, Math.floor((x + 1) / scale)));
    const sy0 = Math.floor(y / scale), sy1 = Math.max(sy0 + 1, Math.min(src.h, Math.floor((y + 1) / scale)));
    let r = 0, g = 0, b = 0, a = 0, n = 0;
    for (let sy = sy0; sy < sy1; sy++) for (let sx = sx0; sx < sx1; sx++) {
      const i = (sy * src.w + Math.min(src.w - 1, sx)) * 4, al = src.data[i + 3] / 255;
      r += src.data[i] * al; g += src.data[i + 1] * al; b += src.data[i + 2] * al; a += al; n++;
    }
    const o = y * w + x;
    A[o] = a / n;
    if (a > 0) { R[o] = r / a; G[o] = g / a; B[o] = b / a; }
  }
  for (let y = 0; y < th; y++) for (let x = 0; x < w; x++) {
    const o = y * w + x, r = R[o], g = G[o], b = B[o];
    Y[o] = 16 + 0.1826 * r + 0.6142 * g + 0.062 * b; // BT.709, video levels
    if (!(x & 1)) {
      const c = y * (w / 2) + x / 2, o2 = o + 1, a0 = A[o], a1 = A[o2], t = a0 + a1 || 1; // the pair's colour, by how much each shows
      const rr = (R[o] * a0 + R[o2] * a1) / t, gg = (G[o] * a0 + G[o2] * a1) / t, bb = (B[o] * a0 + B[o2] * a1) / t;
      U[c] = 128 - 0.1006 * rr - 0.3386 * gg + 0.4392 * bb; V[c] = 128 + 0.4392 * rr - 0.3989 * gg - 0.0403 * bb;
    }
  }
  return { w, h: th, Y, U, V, A };
}
function drawTag(data, fw, fh, tag) {
  if (!tag || tag.w > fw || tag.h > fh) return;
  const x0 = Math.round((fw * 0.04) / 2) * 2, y0 = Math.round(fh * 0.05), row = fw * 2;
  for (let y = 0; y < tag.h; y++) {
    let o = (y0 + y) * row + x0 * 2;
    for (let x = 0; x < tag.w; x += 2, o += 4) {
      const t = y * tag.w + x, a0 = tag.A[t], a1 = tag.A[t + 1];
      if (!a0 && !a1) continue;
      const c = y * (tag.w / 2) + x / 2, ac = (a0 + a1) / 2;
      data[o] += (tag.U[c] - data[o]) * ac; data[o + 2] += (tag.V[c] - data[o + 2]) * ac;
      data[o + 1] += (tag.Y[t] - data[o + 1]) * a0; data[o + 3] += (tag.Y[t + 1] - data[o + 3]) * a1;
    }
  }
}

// ---------- the replay ----------
const SPEEDS = [0.25, 0.5, 0.75, 1];
class Replay extends EventEmitter {
  // ndi: ndi.js; bin: FFmpeg; take(): the take to replay from (the one recording, or the last one)
  // sources(): the sources that can go out live (the ticked ones)
  constructor({ ndi, bin, take, sources = () => [], name = 'Showcaller Replay' }) {
    super();
    Object.assign(this, { ndi, bin, getTake: take, sources, name });
    this.mode = 'live'; this.angle = ''; this.take = null;
    this.pos = 0; this.speed = 1; this.playing = false;
    this.inAt = null; this.outAt = null; this.clips = []; this.playlist = null; this.clipEnd = null;
    this.reader = null; this.nextReader = null; this.history = new Map(); this.historyBytes = 0;
    this.out = null; this.outIdx = -1; this.outKey = ''; this.tagSrc = null; this.tags = new Map(); this.tagOn = true;
    this.sender = null; this.enabled = false; this.liveStop = null; this.liveAngle = '';
    this.timer = null; this.lastSent = -1;
  }
  // ----- output -----
  setOutput(on) {
    on = !!on;
    if (on === this.enabled) return;
    this.enabled = on;
    if (on) { this.sender = this.ndi.sender(this.name); if (!this.sender) this.enabled = false; }
    else { this.sender?.close(); this.sender = null; }
    this.syncLive();
  }
  setTagImage(img) { this.tagSrc = img && img.w > 0 && img.h > 0 && img.data?.length === img.w * img.h * 4 ? img : null; this.tags.clear(); this.outKey = ''; }
  setTag(on) { this.tagOn = !!on; this.outKey = ''; }
  connections() { return this.sender ? this.sender.connections() : 0; }
  // Live: the chosen angle straight through (no tag), as it arrives.
  syncLive() {
    const want = this.mode === 'live' && this.angle ? this.angle : ''; // (watched for the window's monitor even with the output off)
    if (want === this.liveAngle) return;
    this.liveStop?.(); this.liveStop = null; this.liveAngle = want;
    if (!want) return;
    this.liveStop = this.ndi.watch(want, {
      frame: (f) => { if (f.fmt === 'uyvy') { this.sender?.video(f); this.emit('frame', f); } },
      audio: (a) => {
        const out = new Float32Array(a.n * 2); out.set(a.left.subarray(0, a.n), 0); out.set(a.right.subarray(0, a.n), a.n);
        this.sender?.audio(out, a.n, a.rate);
      },
    });
  }
  // ----- what can be replayed -----
  angles(take = this.take || this.getTake()) {
    return take ? take.tracks.filter((t) => t.parts.length).map((t) => t.name) : [];
  }
  track(name = this.angle) { return this.take?.tracks.find((t) => t.name === name && t.parts.length) || null; }
  first(take = this.take) { const ts = take?.tracks.filter((t) => t.parts.length) || []; return ts.length ? Math.min(...ts.map((t) => t.parts[0].start)) : 0; }
  edge(take = this.take) { return !take ? 0 : take.ended ? take.endAt - 40 : Date.now() - EDGE_MS; }
  clamp(ms, slack = 0) { return Math.max(this.first(), Math.min(this.edge() + slack, ms)); }
  partAt(track, ms) { let p = track.parts[0]; for (const x of track.parts) if (x.start <= ms) p = x; return p; }
  // ----- the controls -----
  setAngle(name) {
    name = String(name || '');
    if (this.mode === 'replay') {
      if (!this.track(name)) return false;
      this.angle = name; this.dropReaders(); this.outKey = '';
    } else this.angle = name;
    this.syncLive(); this.emit('change');
    return true;
  }
  // Cue `seconds` back from now (or to the moment `at`), paused, ready to play.
  cue({ seconds, at, angle, play = false } = {}) {
    const take = this.getTake();
    if (!take || !this.angles(take).length) return { ok: false, error: 'Nothing recorded to replay yet. Press Record first.' };
    if (take !== this.take) { this.take = take; this.dropReaders(); this.history.clear(); this.historyBytes = 0; this.inAt = this.outAt = null; this.clips = take.replayClips || (take.replayClips = []); }
    const names = this.angles(take);
    if (angle && names.includes(angle)) this.angle = angle;
    if (!names.includes(this.angle)) this.angle = names[0];
    this.mode = 'replay'; this.playlist = null; this.clipEnd = null;
    // (back from now, or for a take that has finished, back from its end)
    this.pos = this.clamp(at != null ? at : (take.ended ? take.endAt : Date.now()) - (seconds || 10) * 1000);
    this.playing = !!play;
    this.syncLive(); this.startClock(); this.emit('change');
    return { ok: true };
  }
  play(on = !this.playing) {
    if (this.mode !== 'replay') return this.cue({ seconds: 10, play: true });
    this.playing = !!on;
    if (this.playing && this.pos >= this.edge() - 40 && this.take?.ended) this.pos = this.first(); // at the end of a finished take: from the top
    this.emit('change');
    return { ok: true };
  }
  setSpeed(v) { this.speed = Math.max(0.05, Math.min(2, Number(v) || 1)); this.emit('change'); return { ok: true }; }
  // the next preset speed up or down (25, 50, 75, 100%)
  speedStep(dir) {
    const v = dir > 0 ? SPEEDS.find((x) => x > this.speed + 1e-6) ?? Math.max(1, this.speed) : [...SPEEDS].reverse().find((x) => x < this.speed - 1e-6) ?? SPEEDS[0];
    return this.setSpeed(v);
  }
  step(frames) {
    if (this.mode !== 'replay') return;
    const p = this.partAt(this.track(), this.pos);
    this.playing = false; this.clipEnd = null; this.playlist = null;
    this.pos = this.clamp(this.pos + (frames * 1000 * p.D) / p.N);
    this.emit('change');
  }
  seek(ms) { if (this.mode !== 'replay') return; this.pos = this.clamp(Number(ms)); this.emit('change'); }
  live() {
    this.mode = 'live'; this.playing = false; this.playlist = null; this.clipEnd = null;
    this.stopClock(); this.dropReaders(); this.history.clear(); this.historyBytes = 0; this.out = null;
    if (!this.angle || !this.sources().includes(this.angle)) this.angle = this.sources().includes(this.angle) ? this.angle : this.sources()[0] || '';
    this.syncLive(); this.emit('change');
  }
  // ----- clips -----
  markIn() { if (this.mode === 'replay') { this.inAt = this.pos; if (this.outAt != null && this.outAt <= this.inAt) this.outAt = null; this.emit('change'); } }
  markOut() { if (this.mode === 'replay') { this.outAt = this.pos; if (this.inAt != null && this.inAt >= this.outAt) this.inAt = null; this.emit('change'); } }
  saveClip(label) {
    if (this.mode !== 'replay' || !this.take) return { ok: false, error: 'Cue a replay first.' };
    let a = this.inAt, b = this.outAt;
    if (a == null && b == null) return { ok: false, error: 'Set an In point (I) and an Out point (O) first.' };
    if (a == null) a = Math.max(this.first(), b - 5000); // only an out: the five seconds before it
    if (b == null) b = this.pos > a + 200 ? this.pos : Math.min(this.edge(), a + 5000); // only an in: up to here, or five seconds
    const n = (this.clips.reduce((m, c) => Math.max(m, c.n), 0) || 0) + 1;
    const c = { n, angle: this.angle, in: a, out: b, label: String(label || '').trim().slice(0, 80) || `Clip ${n}` };
    this.clips.push(c); this.inAt = this.outAt = null;
    this.writeClips(); this.emit('change');
    return { ok: true, clip: c };
  }
  deleteClip(n) { const i = this.clips.findIndex((c) => c.n === Number(n)); if (i >= 0) { this.clips.splice(i, 1); this.writeClips(); this.emit('change'); } }
  renameClip(n, label) { const c = this.clips.find((x) => x.n === Number(n)); if (c) { c.label = String(label || '').trim().slice(0, 80) || `Clip ${c.n}`; this.writeClips(); this.emit('change'); } }
  playClip(n, { all = false } = {}) {
    const i = n == null ? 0 : this.clips.findIndex((c) => c.n === Number(n));
    const c = this.clips[i];
    if (!c) return { ok: false, error: 'No clips saved yet.' };
    const r = this.cue({ at: c.in, angle: c.angle, play: true });
    if (!r.ok) return r;
    this.clipEnd = c.out; this.playlist = all ? { i } : null;
    this.emit('change');
    return { ok: true };
  }
  clipDone() {
    if (this.playlist && this.playlist.i + 1 < this.clips.length) { const i = this.playlist.i + 1; this.playClip(this.clips[i].n, { all: true }); this.playlist = { i }; return; }
    this.playing = false; this.clipEnd = null; this.playlist = null; this.emit('change');
  }
  // "Replay clips.csv" in the take folder: each clip's angle and its timecodes, for the edit
  writeClips() {
    const t = this.take; if (!t?.dir) return;
    const q = (s) => `"${String(s).replace(/"/g, '""')}"`;
    const tc = (ms) => todTimecode(ms, t.N, t.D);
    const rows = ['Clip,Name,Angle,In (timecode),Out (timecode),Length (seconds)', ...this.clips.map((c) => [c.n, q(c.label), q(c.angle), tc(c.in), tc(c.out), ((c.out - c.in) / 1000).toFixed(2)].join(','))];
    try { fs.writeFileSync(path.join(t.dir, 'Replay clips.csv'), rows.join('\r\n') + '\r\n'); } catch {}
  }
  // ----- the clock -----
  startClock() {
    if (this.timer) return;
    this.tickAt = Date.now(); this.lastSent = -1;
    const loop = () => {
      if (!this.timer) return;
      const period = this.period();
      try { this.tick(period); } catch (e) { this.emit('error', e); }
      this.tickAt += period;
      const now = Date.now();
      if (now - this.tickAt > 250) this.tickAt = now; // fell well behind (the computer was busy): carry on from now
      this.timer = setTimeout(loop, Math.max(0, this.tickAt + period - now));
    };
    this.timer = setTimeout(loop, 0);
  }
  stopClock() { clearTimeout(this.timer); this.timer = null; }
  period() { const t = this.track(); if (!t) return 40; const p = this.partAt(t, this.pos); return (1000 * p.D) / p.N; }
  dropReaders() { this.reader?.close(); this.nextReader?.close(); this.reader = this.nextReader = null; }
  remember(list) {
    for (const f of list) {
      if (this.history.has(f.key)) continue;
      this.history.set(f.key, f.data); this.historyBytes += f.data.length;
    }
    while (this.historyBytes > HISTORY_BYTES && this.history.size) { const [k, d] = this.history.entries().next().value; this.history.delete(k); this.historyBytes -= d.length; }
  }
  // The last picture of `part` that can be read now: all of it if it's finished, or up to the replay edge.
  lastAvail(part) {
    const t = this.track();
    if (this.take.ended || !t || t.parts[t.parts.length - 1] !== part) return Infinity;
    return Math.floor(((Date.now() - READ_EDGE_MS - part.start) * part.N) / (part.D * 1000));
  }
  // The picture for `idx` of `part`, from what's been read, the history, or a new read of the file.
  picture(part, idx) {
    const key = `${part.file}#${idx}`;
    let r = this.reader;
    const nx = this.nextReader;
    // the one reading on from where this one stops takes over
    if (r && nx && nx.part === part && idx >= nx.first && (idx > r.last || (r.done && !r.q.length))) { r.close(); r = this.reader = nx; this.nextReader = null; }
    if (r && r.part === part && idx >= r.low && idx <= r.last && idx < r.next + AHEAD * 2) {
      const gone = [], f = r.take(idx, gone);
      this.remember(gone.map((g) => ({ key: `${part.file}#${g.idx}`, data: g.data })));
      // a second and a half before this one stops, start the next from where it stops (once there's at least
      // three quarters of a second more to read, or straight away when this one is nearly done)
      const fps = part.N / part.D;
      if (!this.nextReader && r.last !== Infinity && !r.failed && r.next >= r.last - 1.5 * fps) {
        const last = this.lastAvail(part);
        if (last >= r.last + 0.75 * fps || (idx >= r.last - 0.3 * fps && last > r.last)) this.nextReader = new Reader(this.bin, part, r.last + 1, last);
      }
      if (f) return { data: f.data, idx, key, reader: r };
      if (!r.done) return null; // still coming
    }
    const h = this.history.get(key);
    if (h) return { data: h, idx, key };
    // a new read from here (but not on every tick while one is starting up, as when scrubbing)
    if (r && !r.q.length && !r.done && Date.now() - r.started < 400 && r.part === part) return null;
    if (r && r.done && r.part === part && idx > r.last && Date.now() - r.started < 250) return null;
    this.reader?.close(); this.nextReader?.close(); this.nextReader = null;
    const last = this.lastAvail(part);
    this.reader = new Reader(this.bin, part, Math.min(idx, Math.max(0, last)), last);
    return null;
  }
  tick(period) {
    if (this.mode !== 'replay') return;
    const track = this.track();
    if (!track) return;
    if (this.playing) {
      const was = this.pos;
      // (half a second of slack, so playing on from a cue at the edge keeps to its own steady clock)
      this.pos = this.clamp(this.pos + period * this.speed, this.take.ended ? 0 : 500);
      if (this.clipEnd != null && this.pos >= this.clipEnd) { this.pos = this.clipEnd; this.clipDone(); }
      else if (this.take.ended && this.pos >= this.edge() && was >= this.edge()) { this.playing = false; this.emit('change'); }
    }
    const part = this.partAt(track, this.pos);
    const idx = Math.max(0, Math.floor(((this.pos - part.start) * part.N) / (part.D * 1000) + 1e-6));
    const pic = this.picture(part, idx);
    if (pic) {
      const advanced = pic.key !== this.outKey;
      if (advanced) {
        const data = Buffer.from(pic.data);
        if (this.tagOn) {
          let tag = this.tags.get(part.h);
          if (tag === undefined) { tag = tagFor(this.tagSrc, part.h); this.tags.set(part.h, tag); }
          drawTag(data, part.w, part.h, tag);
        }
        this.out = { w: part.w, h: part.h, N: part.N, D: part.D, fmt: 'uyvy', data };
        // sound only at full speed, playing on from the picture before
        this.outSound = this.playing && Math.abs(this.speed - 1) < 1e-6 && pic.reader && pic.idx === this.lastSent + 1 ? pic.reader.sound(pic.idx) : null;
        this.outKey = pic.key; this.lastSent = pic.idx;
        this.emit('frame', this.out);
      } else this.outSound = null;
    } else this.outSound = null;
    if (!this.out || !this.sender) return;
    const tcUnits = Math.round(((this.pos - new Date(new Date(this.pos).toDateString()).getTime()) * 1e4));
    this.sender.video(this.out, tcUnits);
    const spf = Math.round((RATE * period) / 1000);
    const s = this.outSound || { data: new Float32Array(spf * 2), n: spf };
    this.sender.audio(s.data, s.n, RATE, tcUnits);
  }
  status() {
    const take = this.take, t = this.track(), p = t ? this.partAt(t, this.pos) : null;
    const N = p?.N || take?.N || 25, D = p?.D || take?.D || 1;
    const cur = this.getTake();
    return {
      mode: this.mode, angle: this.angle, enabled: this.enabled, name: this.name,
      angles: this.mode === 'replay' ? this.angles(take) : this.sources(),
      canReplay: !!cur && this.angles(cur).length > 0,
      take: take ? { dir: take.dir, folder: path.basename(take.dir), ended: !!take.ended } : null,
      first: this.mode === 'replay' ? this.first() : 0, edge: this.mode === 'replay' ? this.edge() : 0, pos: this.pos,
      tc: this.mode === 'replay' ? todTimecode(this.pos, N, D) : '', fps: Math.round((N / D) * 100) / 100,
      playing: this.playing, speed: this.speed, inAt: this.inAt, outAt: this.outAt,
      clips: this.clips.map((c) => ({ ...c, tcIn: take ? todTimecode(c.in, take.N, take.D) : '', secs: (c.out - c.in) / 1000 })),
      playlist: this.playlist ? this.playlist.i : null, clipEnd: this.clipEnd,
    };
  }
  close() { this.stopClock(); this.dropReaders(); this.liveStop?.(); this.liveStop = null; this.sender?.close(); this.sender = null; }
}

module.exports = { Replay, Reader, tagFor, drawTag, EDGE_MS, SPEEDS, timecode };
