// NDI for Showcaller Replay and ISO: receiving (taken from Showcaller Multiview's, at full quality, every frame), and sending
// the replay output.
// Talks to the NDI library: the copy built into the app (Resources/ndi), or else the free NDI Runtime that
// comes with NDI Tools on this computer.
// NDI® is a registered trademark of Vizrt NDI AB. https://ndi.video
const fs = require('fs');
const path = require('path');
const { EventEmitter } = require('events');
const ED = require('./edition');

const LINKS = { win32: 'https://ndi.link/NDIRedistV6', darwin: 'https://ndi.link/NDIRedistV6Apple' };
const state = { ok: false, reason: 'NDI has not been started', version: '', lib: '', link: LINKS[process.platform] || 'https://ndi.video/tools' };
const events = new EventEmitter();
let koffi = null, L = null, finder = null, findTimer = null, names = [], look = () => {}, extra = '';
const urls = new Map(); // source name -> address, as last seen by the finder

function candidates(extraDirs = []) {
  const file = process.platform === 'win32' ? 'Processing.NDI.Lib.x64.dll' : process.platform === 'darwin' ? 'libndi.dylib' : 'libndi.so.6';
  const out = [];
  if (process.env.NDI_LIB) out.push(process.env.NDI_LIB);
  for (const d of extraDirs) out.push(path.join(d, file));
  if (process.platform === 'win32') {
    for (const v of ['NDI_RUNTIME_DIR_V6', 'NDI_RUNTIME_DIR_V5', 'NDI_RUNTIME_DIR_V4']) if (process.env[v]) out.push(path.join(process.env[v], file));
    for (const v of ['6', '5']) out.push(`C:\\Program Files\\NDI\\NDI ${v} Runtime\\v${v}\\${file}`, `C:\\Program Files\\NDI\\NDI ${v} Tools\\Runtime\\${file}`);
  } else if (process.platform === 'darwin') {
    out.push('/usr/local/lib/libndi.dylib', '/Library/NDI SDK for Apple/lib/macOS/libndi.dylib', '/opt/homebrew/lib/libndi.dylib');
  } else out.push('/usr/lib/libndi.so.6', '/usr/local/lib/libndi.so.6', '/usr/lib/x86_64-linux-gnu/libndi.so.6');
  return out;
}

function makeFinder(extraIps) {
  finder = L.find_create({ show_local_sources: true, p_groups: null, p_extra_ips: extraIps || null });
  if (!finder) throw new Error('NDI could not start looking for sources');
}

function start({ extraIps = '', extraDirs = [] } = {}) {
  if (state.ok) return state;
  try { koffi = require('koffi'); }
  catch { state.reason = `A part of the app is missing (koffi). Reinstall ${ED.name}.`; return state; }
  const found = candidates(extraDirs).find((f) => { try { return fs.existsSync(f); } catch { return false; } });
  if (!found) { state.reason = `The NDI Runtime is not installed on this computer. Install NDI Tools (free), then restart ${ED.name}.`; state.needsRuntime = true; return state; }
  try {
    const lib = koffi.load(found);
    koffi.struct('NDIlib_source_t', { p_ndi_name: 'const char*', p_url_address: 'const char*' });
    koffi.struct('NDIlib_find_create_t', { show_local_sources: 'bool', p_groups: 'const char*', p_extra_ips: 'const char*' });
    koffi.struct('NDIlib_recv_create_v3_t', { source_to_connect_to: 'NDIlib_source_t', color_format: 'int', bandwidth: 'int', allow_video_fields: 'bool', p_ndi_recv_name: 'const char*' });
    koffi.struct('NDIlib_video_frame_v2_t', {
      xres: 'int', yres: 'int', FourCC: 'int', frame_rate_N: 'int', frame_rate_D: 'int', picture_aspect_ratio: 'float', frame_format_type: 'int',
      timecode: 'int64_t', p_data: 'void*', line_stride_in_bytes: 'int', p_metadata: 'void*', timestamp: 'int64_t',
    });
    koffi.struct('NDIlib_send_create_t', { p_ndi_name: 'const char*', p_groups: 'const char*', clock_video: 'bool', clock_audio: 'bool' });
    koffi.struct('NDIlib_audio_frame_v2_t', {
      sample_rate: 'int', no_channels: 'int', no_samples: 'int', timecode: 'int64_t', p_data: 'void*', channel_stride_in_bytes: 'int', p_metadata: 'void*', timestamp: 'int64_t',
    });
    koffi.struct('NDIlib_audio_frame_v3_t', {
      sample_rate: 'int', no_channels: 'int', no_samples: 'int', timecode: 'int64_t', FourCC: 'int', p_data: 'void*',
      channel_stride_in_bytes: 'int', p_metadata: 'void*', timestamp: 'int64_t',
    });
    L = {
      initialize: lib.func('bool NDIlib_initialize()'),
      version: lib.func('const char* NDIlib_version()'),
      find_create: lib.func('void* NDIlib_find_create_v2(const NDIlib_find_create_t* c)'),
      find_destroy: lib.func('void NDIlib_find_destroy(void* f)'),
      find_sources: lib.func('const void* NDIlib_find_get_current_sources(void* f, _Out_ uint32_t* n)'),
      recv_create: lib.func('void* NDIlib_recv_create_v3(const NDIlib_recv_create_v3_t* c)'),
      recv_destroy: lib.func('void NDIlib_recv_destroy(void* r)'),
      recv_capture: lib.func('int NDIlib_recv_capture_v3(void* r, _Out_ NDIlib_video_frame_v2_t* v, _Out_ NDIlib_audio_frame_v3_t* a, void* m, uint32_t timeout)'),
      recv_free: lib.func('void NDIlib_recv_free_video_v2(void* r, const NDIlib_video_frame_v2_t* v)'),
      recv_free_audio: lib.func('void NDIlib_recv_free_audio_v3(void* r, const NDIlib_audio_frame_v3_t* a)'),
      send_create: lib.func('void* NDIlib_send_create(const NDIlib_send_create_t* c)'),
      send_destroy: lib.func('void NDIlib_send_destroy(void* s)'),
      send_video_async: lib.func('void NDIlib_send_send_video_async_v2(void* s, const NDIlib_video_frame_v2_t* v)'),
      send_audio: lib.func('void NDIlib_send_send_audio_v2(void* s, const NDIlib_audio_frame_v2_t* a)'),
      send_connections: lib.func('int NDIlib_send_get_no_connections(void* s, uint32_t timeout)'),
      send_name: lib.func('const void* NDIlib_send_get_source_name(void* s)'),
    };
    if (!L.initialize()) throw new Error('this computer’s processor is not supported by NDI');
    try { state.version = String(L.version() || ''); } catch {}
    extra = extraIps; makeFinder(extraIps);
    state.ok = true; state.reason = ''; state.lib = found; state.builtIn = extraDirs.some((d) => found.startsWith(d)); delete state.needsRuntime;
    look = () => {
      try {
        const n = [0], ptr = L.find_sources(finder, n);
        const list = n[0] && ptr ? koffi.decode(ptr, koffi.array('NDIlib_source_t', n[0])).filter((s) => s.p_ndi_name) : [];
        for (const s of list) if (s.p_url_address) urls.set(s.p_ndi_name, s.p_url_address);
        const sorted = list.map((s) => s.p_ndi_name).filter((n) => !own.has(n)).sort((a, b) => a.localeCompare(b));
        if (sorted.join('\n') !== names.join('\n')) { names = sorted; events.emit('sources', names); }
      } catch (e) { events.emit('error', e); }
    };
    look(); findTimer = setInterval(look, 2000); findTimer.unref?.();
  } catch (e) { L = null; state.ok = false; state.reason = `NDI could not be started: ${e.message}`; }
  return state;
}

// Cameras on another network range (or reached over Tailscale) can be listed by IP address.
function setExtraIps(extraIps) {
  if (!state.ok) return;
  try { L.find_destroy(finder); } catch {}
  names = []; events.emit('sources', names);
  extra = extraIps; makeFinder(extraIps);
}

// Refresh: start looking for sources again from scratch, and reconnect any source that has no picture now
// (instead of waiting for the next automatic retry). Sources that are sending pictures are left alone.
function refresh() {
  if (!state.ok) return false;
  try { L.find_destroy(finder); } catch {}
  makeFinder(extra);
  for (const r of receivers.values()) r.kick = true;
  for (const ms of [300, 1500, 4000]) setTimeout(() => look(), ms).unref?.();
  return true;
}

// ---------- receiving ----------
// One receiver per source, shared by the preview and the recording. Pictures arrive as UYVY (YUV 4:2:2, what
// cameras and switchers send, so nothing is converted here), or BGRA from a source with transparency.
// Always the full-quality stream and every frame: this is what gets recorded.
const receivers = new Map();
function receiver(name) {
  let r = receivers.get(name);
  if (r) return r;
  if (!state.ok) return null;
  let quietTries = 0;
  // Every other retry connects by name alone, letting NDI find the source itself, in case the address
  // the finder has for it is one this computer can't reach.
  const connect = (byName = false) => {
    const url = byName ? null : urls.get(name) || null;
    const inst = L.recv_create({ source_to_connect_to: { p_ndi_name: name, p_url_address: url }, color_format: 1 /* UYVY_BGRA */, bandwidth: 100, allow_video_fields: false, p_ndi_recv_name: ED.name });
    return inst ? { inst, seen: urls.get(name) || null, since: Date.now() } : null;
  };
  let conn = connect();
  if (!conn) return null;
  r = { name, users: new Set(), alive: true, lastAt: 0, w: 0, h: 0, N: 0, D: 1, fps: 0, fmt: '', ch: 0, rate: 0 };
  receivers.set(name, r);
  // A source that restarts can come back at a new address: reconnect when the finder sees it move,
  // or after 10 seconds without a picture.
  const reconnectIfNeeded = () => {
    const quiet = Date.now() - Math.max(r.lastAt, conn.since);
    if (quiet < 2000) return;
    const moved = urls.has(name) && urls.get(name) !== conn.seen, kicked = r.kick;
    r.kick = false;
    if (!moved && !kicked && quiet < 10000) return;
    const next = connect(!moved && ++quietTries % 2 === 0);
    if (!next) return;
    try { L.recv_destroy(conn.inst); } catch {}
    conn = next;
  };
  const loop = () => {
    if (!r.alive) { try { L.recv_destroy(conn.inst); } catch {} return; }
    reconnectIfNeeded();
    const v = {}, a = {}, inst = conn.inst;
    L.recv_capture.async(inst, v, a, null, 250, (err, kind) => {
      if (err) { events.emit('error', err); setTimeout(loop, 500); return; }
      // keep the loop going whatever happens below, or this source would stay stuck
      try { if (kind === 1 && v.p_data) {
        try {
          const fmt = v.FourCC === UYVY ? 'uyvy' : v.FourCC === BGRA || v.FourCC === BGRX ? 'bgra' : '';
          r.lastAt = Date.now(); r.w = v.xres; r.h = v.yres; r.fmt = fmt;
          r.N = v.frame_rate_N > 0 ? v.frame_rate_N : 30; r.D = v.frame_rate_D > 0 ? v.frame_rate_D : 1;
          r.fps = Math.round((r.N / r.D) * 100) / 100;
          if (r.alive && fmt && r.users.size && v.xres > 0 && v.yres > 0 && v.xres <= 8192 && v.yres <= 8192) {
            const row = v.xres * (fmt === 'uyvy' ? 2 : 4), stride = v.line_stride_in_bytes || row;
            // decode copies the picture into memory the app owns (Electron doesn't allow borrowing the library's)
            const raw = koffi.decode(v.p_data, koffi.array('uint8_t', stride * v.yres, 'Typed'));
            const src = Buffer.from(raw.buffer, raw.byteOffset, raw.length);
            let data;
            if (stride === row) data = src;
            else { data = Buffer.allocUnsafe(row * v.yres); for (let y = 0; y < v.yres; y++) src.copy(data, y * row, y * stride, y * stride + row); }
            const f = { w: v.xres, h: v.yres, N: r.N, D: r.D, fps: r.fps, fmt, data, at: r.lastAt };
            for (const u of r.users) { try { u.frame?.(f); } catch (e) { events.emit('error', e); } }
          }
        } finally { try { L.recv_free(inst, v); } catch {} }
      } else if (kind === 2) {
        try { if (r.alive && a.p_data) sound(r, a); } finally { try { L.recv_free_audio(inst, a); } catch {} }
      } } catch (e) { events.emit('error', e); }
      setImmediate(loop);
    });
  };
  loop();
  return r;
}
// Sound: NDI sends 32-bit float audio, one block per channel. Users get the first two channels (a mono source
// goes to both sides) with the sample rate, and how many channels the source has.
function sound(r, a) {
  const ch = a.no_channels, n = a.no_samples;
  if (ch < 1 || n < 1 || n > 96000 || ch > 64 || a.FourCC !== FLTP) return;
  r.ch = ch; r.rate = a.sample_rate;
  if (!r.users.size) return;
  const stride = a.channel_stride_in_bytes || n * 4;
  const plane = (c) => koffi.decode(a.p_data, c * stride, koffi.array('float', n, 'Typed'));
  const L0 = plane(0), R0 = ch > 1 ? plane(1) : L0;
  const s = { rate: a.sample_rate, ch, n, left: L0, right: R0 };
  for (const u of r.users) { try { u.audio?.(s); } catch (e) { events.emit('error', e); } }
}
const FLTP = 0x70544c46; // 'FLTp'
const UYVY = 0x59565955, BGRA = 0x41524742, BGRX = 0x58524742; // 'UYVY', 'BGRA', 'BGRX'

// user: { frame?({w,h,N,D,fps,fmt,data,at}), audio?({rate,ch,n,left,right}) }. Returns a function that stops it.
function watch(name, user) {
  const r = receiver(name);
  if (!r) return null;
  r.users.add(user);
  return () => { r.users.delete(user); if (!r.users.size) { r.alive = false; receivers.delete(name); } };
}
// What a source is sending now: { w, h, fps, fmt, ch, rate, lastAt } or null if nothing is watching it.
function info(name) {
  const r = receivers.get(name);
  return r ? { w: r.w, h: r.h, fps: r.fps, N: r.N, D: r.D, fmt: r.fmt, ch: r.ch, rate: r.rate, lastAt: r.lastAt } : null;
}

// ---------- sending (the replay output) ----------
// An NDI source on the network ("COMPUTER (name)"). Pictures go as UYVY and are compressed by NDI on its own
// thread (the "async" send), so the app only hands them over; each picture is kept until the next one replaces it,
// as NDI needs. Sound goes as 32-bit float, one block per channel.
// The names our own outputs have on the network ("THIS COMPUTER (Showcaller Replay)"), kept off the source list so
// the replay output can't be ticked and recorded by mistake.
const own = new Set();
const host = () => require('os').hostname().replace(/\.local\.?$/i, '').toUpperCase();
function sender(name) {
  if (!state.ok) return null;
  const inst = L.send_create({ p_ndi_name: name, p_groups: null, clock_video: false, clock_audio: false });
  if (!inst) return null;
  own.add(`${host()} (${name})`);
  try { const p = L.send_name(inst), s = p && koffi.decode(p, 'NDIlib_source_t'); if (s?.p_ndi_name) own.add(s.p_ndi_name); } catch {}
  if (names.some((n) => own.has(n))) { names = names.filter((n) => !own.has(n)); events.emit('sources', names); }
  let held = [null, null], closed = false;
  return {
    // f: { w, h, N, D, data (UYVY) }, tc: timecode in 100 ns steps since midnight (0: let NDI make one up)
    video(f, tc = 0) {
      if (closed) return;
      L.send_video_async(inst, { xres: f.w, yres: f.h, FourCC: UYVY, frame_rate_N: f.N, frame_rate_D: f.D, picture_aspect_ratio: f.w / f.h, frame_format_type: 1,
        timecode: tc, p_data: f.data, line_stride_in_bytes: f.w * 2, p_metadata: null, timestamp: 0 });
      held = [held[1], f.data];
    },
    // planar: Float32Array of `n` left samples then `n` right
    audio(planar, n, rate = 48000, tc = 0) {
      if (closed || !n) return;
      L.send_audio(inst, { sample_rate: rate, no_channels: 2, no_samples: n, timecode: tc, p_data: Buffer.from(planar.buffer, planar.byteOffset, n * 8), channel_stride_in_bytes: n * 4, p_metadata: null, timestamp: 0 });
    },
    connections() { try { return closed ? 0 : L.send_connections(inst, 0); } catch { return 0; } },
    close() {
      if (closed) return;
      closed = true;
      try { L.send_video_async(inst, null); } catch {} // NDI lets go of the last picture
      try { L.send_destroy(inst); } catch {}
      held = null;
    },
  };
}

function stop() {
  clearInterval(findTimer);
  for (const r of receivers.values()) r.alive = false;
  receivers.clear();
}

// A source's IP address (no port) as the finder last saw it, or ''.
const sourceIp = (name) => String(urls.get(name) || '').replace(/:\d+$/, '').replace(/^\[|\]$/g, '');

module.exports = { candidates, start, stop, state, sources: () => names.slice(), events, watch, info, setExtraIps, refresh, sourceIp, sender, isOwn: (n) => own.has(n) || n === `${host()} (Showcaller Replay)` };
