// The only things the window can ask the app for.
const { contextBridge, ipcRenderer } = require('electron');
const on = (ch) => (cb) => ipcRenderer.on(ch, (_e, ...a) => cb(...a));
contextBridge.exposeInMainWorld('iso', {
  state: () => ipcRenderer.invoke('state'),
  settings: (patch) => ipcRenderer.invoke('settings', patch),
  pickFolder: () => ipcRenderer.invoke('pick-folder'),
  start: () => ipcRenderer.invoke('rec-start'),
  stop: () => ipcRenderer.invoke('rec-stop'),
  mark: (label) => ipcRenderer.invoke('mark', String(label || '')),
  openFolder: (dir) => ipcRenderer.send('open-folder', dir ? String(dir) : ''),
  openLink: (url) => ipcRenderer.send('open-link', String(url)),
  ndiRefresh: () => ipcRenderer.send('ndi-refresh'),
  thumbAck: (name) => ipcRenderer.send('thumb-ack', String(name)),
  thumbSize: (name, px) => ipcRenderer.send('thumb-size', String(name), Number(px)),
  license: (key) => ipcRenderer.invoke('license-set', String(key || '')),
  buy: () => ipcRenderer.send('buy'),
  replay: (cmd, args) => ipcRenderer.invoke('replay', String(cmd), args || {}),
  onSources: on('sources'), onStatus: on('status'), onThumb: on('thumb'), onLevels: on('levels'), onCfg: on('cfg'),
  onNotice: on('notice'), onCommand: on('command'), onEncoders: on('encoders'), onUpdate: on('update'),
  onReplay: on('replay'), onControl: on('control'),
});
