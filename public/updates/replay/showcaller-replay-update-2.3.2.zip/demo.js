// Demo mode for Showcaller Replay: three practice cameras built into the app, for trying recording and replay
// without any NDI gear. They work like NDI sources (the same watch / info calls), as "DEMO (Cam 1 Wide)" and so on.
//
// All three film the same made-up scene from different places: a ball bouncing across a stage. So when a replay
// changes angle, the ball is in the same place in its bounce on every camera, as with real cameras. Each picture also
// shows a running clock (hours, minutes, seconds, frames) and the camera's number, and the sound is a beep on every
// whole second over a little room noise, so the sync between cameras and sound can be seen and heard.
const W = 1280, H = 720, N = 30000, D = 1001, RATE = 48000;

// a colour as Y, U, V (BT.709, video levels)
const yuv = (hex) => {
  const v = parseInt(hex.slice(1), 16), r = v >> 16, g = (v >> 8) & 255, b = v & 255;
  return [Math.round(16 + 0.1826 * r + 0.6142 * g + 0.062 * b), Math.round(128 - 0.1006 * r - 0.3386 * g + 0.4392 * b), Math.round(128 + 0.4392 * r - 0.3989 * g - 0.0403 * b)];
};
// Each camera's view of the stage: how much of it shows and where from, and its colours
const CAMS = [
  { name: 'DEMO (Cam 1 Wide)', n: 1, zoom: 1, cx: 0.5, cy: 0.55, top: yuv('#16233a'), bottom: yuv('#33476a'), floor: yuv('#5a4430'), ball: yuv('#ff9a1f') },
  { name: 'DEMO (Cam 2 Close Up)', n: 2, zoom: 2.2, cx: 0.5, cy: 0.6, top: yuv('#1b1530'), bottom: yuv('#3d2f5c'), floor: yuv('#4a3826'), ball: yuv('#ff9a1f'), follow: true },
  { name: 'DEMO (Cam 3 Side)', n: 3, zoom: 1.4, cx: 0.5, cy: 0.57, top: yuv('#10282a'), bottom: yuv('#24514f'), floor: yuv('#4f3d2b'), ball: yuv('#ff9a1f'), mirror: true },
];
const NAMES = CAMS.map((c) => c.name);

// The ball, at time t (seconds): across the stage and back every 8 seconds, bouncing twice a second
function ball(t) {
  const u = (t % 8) / 8, x = u < 0.5 ? 0.1 + u * 1.6 : 0.9 - (u - 0.5) * 1.6;
  const b = (t * 1.6) % 1, y = 0.78 - 0.42 * 4 * b * (1 - b); // up and down (stage: 0 at the top, 1 at the bottom)
  return { x, y, squash: b < 0.06 || b > 0.94 ? 0.75 : 1 };
}

// ---------- drawing on UYVY (two pixels share U and V) ----------
function fill(buf, x0, y0, x1, y1, [Y, U, V]) {
  x0 = Math.max(0, Math.floor(x0 / 2) * 2); x1 = Math.min(W, Math.ceil(x1 / 2) * 2);
  y0 = Math.max(0, Math.floor(y0)); y1 = Math.min(H, Math.ceil(y1));
  for (let y = y0; y < y1; y++) for (let x = x0, o = (y * W + x0) * 2; x < x1; x += 2, o += 4) { buf[o] = U; buf[o + 1] = Y; buf[o + 2] = V; buf[o + 3] = Y; }
}
function disc(buf, cx, cy, rx, ry, col) {
  for (let y = Math.max(0, Math.floor(cy - ry)); y < Math.min(H, Math.ceil(cy + ry)); y++) {
    const dy = (y + 0.5 - cy) / ry, half = rx * Math.sqrt(Math.max(0, 1 - dy * dy));
    if (half > 0.5) fill(buf, cx - half, y, cx + half, y + 1, col);
  }
}
// Seven-segment digits: a b c d e f g
const SEG = { 0: 'abcdef', 1: 'bc', 2: 'abdeg', 3: 'abcdg', 4: 'bcfg', 5: 'acdfg', 6: 'acdefg', 7: 'abc', 8: 'abcdefg', 9: 'abcdfg' };
function digit(buf, d, x, y, s, col) { // s: height; width is s/2
  const w = s / 2, t = Math.max(2, s / 9), on = SEG[d] || '';
  const r = { a: [x, y, x + w, y + t], b: [x + w - t, y, x + w, y + s / 2], c: [x + w - t, y + s / 2, x + w, y + s], d: [x, y + s - t, x + w, y + s],
    e: [x, y + s / 2, x + t, y + s], f: [x, y, x + t, y + s / 2], g: [x, y + s / 2 - t / 2, x + w, y + s / 2 + t / 2] };
  for (const k of on) fill(buf, ...r[k], col);
}
function text(buf, str, x, y, s, col) {
  for (const ch of str) {
    if (ch === ':') { fill(buf, x + s * 0.1, y + s * 0.25, x + s * 0.2, y + s * 0.35, col); fill(buf, x + s * 0.1, y + s * 0.65, x + s * 0.2, y + s * 0.75, col); x += s * 0.35; }
    else { digit(buf, Number(ch), x, y, s, col); x += s * 0.68; }
  }
}

// The parts of each camera's picture that don't move, made once
const bases = new Map();
function base(cam) {
  if (bases.has(cam.name)) return bases.get(cam.name);
  const b = Buffer.alloc(W * H * 2), horizon = Math.round(H * (0.5 + (cam.cy - 0.55) * cam.zoom * 0.6));
  for (let y = 0; y < H; y++) {
    const f = y / H, sky = y < horizon, c = sky ? cam.top.map((v, i) => Math.round(v + (cam.bottom[i] - v) * f)) : cam.floor;
    fill(b, 0, y, W, y + 1, c);
  }
  // stage lines, so the camera's view is easy to tell apart
  for (let k = -6; k <= 6; k++) {
    const x = W / 2 + ((k * 0.08) - (cam.cx - 0.5)) * W * cam.zoom * (cam.mirror ? -1 : 1);
    fill(b, x - 1, horizon, x + 1, H, [70, 128, 128]);
  }
  fill(b, 0, horizon - 1, W, horizon + 1, [150, 128, 128]);
  // the camera's number, in the box with the clock (bottom right; the top left is where the REPLAY tag goes)
  fill(b, W - 560, H - 104, W - 24, H - 24, [16, 128, 128]); fill(b, W - 560, H - 104, W - 478, H - 24, [60, 128, 128]); digit(b, cam.n, W - 538, H - 92, 56, [235, 128, 128]);
  bases.set(cam.name, b);
  return b;
}

function picture(cam, frame) {
  const t = (frame * D) / N, buf = Buffer.allocUnsafe(W * H * 2);
  base(cam).copy(buf);
  const p = ball(t);
  let sx = p.x, sy = p.y;
  if (cam.mirror) sx = 1 - sx;
  // the close-up follows the ball (a little loosely, like a camera operator would)
  const cx = cam.follow ? 0.5 + (p.x - 0.5) * 0.85 : cam.cx, cy = cam.follow ? cam.cy + (p.y - 0.62) * 0.55 : cam.cy;
  const px = W / 2 + (sx - (cam.mirror ? 1 - cx : cx)) * W * cam.zoom, py = H / 2 + (sy - cy) * H * cam.zoom;
  const r = 26 * cam.zoom;
  disc(buf, px, H / 2 + (0.8 - cy) * H * cam.zoom + r * 0.2, r * 1.1 * (0.6 + 0.4 * (p.y - 0.36) / 0.42), r * 0.25, [24, 128, 128]); // shadow (smaller when the ball is high)
  disc(buf, px, py, r / p.squash ** 0.5, r * p.squash, cam.ball);
  disc(buf, px - r * 0.3, py - r * 0.35, r * 0.25, r * 0.2, [235, 110, 150]); // shine
  // the clock: the time of day of this frame, as HH:MM:SS:FF (for reading by eye)
  const sec = Math.floor(t) % 86400, ff = Math.floor((t % 1) * 30);
  const p2 = (n) => String(n).padStart(2, '0');
  text(buf, `${p2(Math.floor(sec / 3600))}:${p2(Math.floor(sec / 60) % 60)}:${p2(sec % 60)}:${p2(ff)}`, W - 452, H - 92, 56, [235, 128, 128]);
  return buf;
}

// Sound for one frame: room noise, and a 1 kHz beep for the first 60 ms of every whole second (louder on camera 1)
function sound(cam, frame, n, state) {
  const L = new Float32Array(n), R = new Float32Array(n), t0 = (frame * D) / N;
  for (let i = 0; i < n; i++) {
    const t = t0 + i / RATE, beep = t % 1 < 0.06 ? (cam.n === 1 ? 0.35 : 0.2) * Math.sin(2 * Math.PI * 1000 * t) : 0;
    state.noise = state.noise * 0.95 + (Math.random() - 0.5) * 0.02;
    L[i] = beep + state.noise; R[i] = beep * 0.9 + state.noise;
  }
  return { rate: RATE, ch: 2, n, left: L, right: R };
}

// ---------- the sources ----------
const running = new Map(); // name -> { users, timer, lastAt }
let on = false;
function setOn(v) { on = !!v; if (!on) for (const [n, r] of running) { clearTimeout(r.timer); running.delete(n); } }
function start(name) {
  const cam = CAMS.find((c) => c.name === name);
  const r = { users: new Set(), lastAt: 0, frame: 0, noise: { noise: 0 }, acc: 0 };
  // frames counted from midnight, so every camera is on the same frame at the same moment
  const t0 = Date.now(), midnight = new Date(new Date().toDateString()).getTime(), f0 = Math.floor(((t0 - midnight) * N) / (D * 1000));
  let k = 0;
  const tick = () => {
    if (!running.has(name)) return;
    const at = Date.now(), frame = f0 + k;
    const f = { w: W, h: H, N, D, fps: Math.round((N / D) * 100) / 100, fmt: 'uyvy', data: picture(cam, frame), at };
    r.lastAt = at;
    r.acc += (RATE * D) / N; const n = Math.floor(r.acc); r.acc -= n;
    const a = sound(cam, frame, n, r.noise);
    for (const u of r.users) { try { u.frame?.(f); u.audio?.(a); } catch {} }
    k++;
    r.timer = setTimeout(tick, Math.max(0, t0 + (k * D * 1000) / N - Date.now()));
  };
  running.set(name, r);
  r.timer = setTimeout(tick, 0);
  return r;
}
module.exports = {
  NAMES,
  isDemo: (name) => NAMES.includes(name),
  setOn, get on() { return on; },
  sources: () => (on ? NAMES.slice() : []),
  watch(name, user) {
    if (!on || !NAMES.includes(name)) return null;
    const r = running.get(name) || start(name);
    r.users.add(user);
    return () => { r.users.delete(user); if (!r.users.size) { clearTimeout(r.timer); running.delete(name); } };
  },
  info(name) { const r = running.get(name); return r ? { w: W, h: H, fps: Math.round((N / D) * 100) / 100, N, D, fmt: 'uyvy', ch: 2, rate: RATE, lastAt: r.lastAt } : null; },
  picture, CAMS, // (for testing)
};
