/*! Showcaller · Copyright (c) 2026 Gotham Media House. All rights reserved. Proprietary; use only under license. */
// One-click updates, the same in every Showcaller app (keep this file identical in each).
//
// The app starts here (package.json "main"). Normally it runs the copy it was built with. After an
// update it runs the newer copy kept in the user data folder (updates/current), using this build's
// Electron and libraries, the way Showcaller Studio does. A rebuilt app that is newer than the
// installed update wins, and an update that fails to start (twice) is set aside for the one before.
//
// Updates are zips of the app's own files, signed with update-key.pem (the same key as Studio's
// updates, kept in "Showcaller Studio Admin (keep private)"). An unsigned or changed zip is refused.
// main.js asks showcallerstudio.com/api/<app>/latest as before; when the answer has a "zip", the
// "Update available" button and Help → Check for Updates call offer(), which downloads, checks
// and installs it, then restarts when the operator says so.
//
// From the command line (plain node, on the Mac that has the key):
//   node sc-update.js pack <app folder> <update-key.pem> [output folder]
// makes "<name>-update-<version>.zip" from the files in package.json build.files, signed, and
// prints its details for the website (public/updates/<app>/latest.json).
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const vm = require('vm');
const crypto = require('crypto');

const UPDATE_PUBLIC_KEY = 'MCowBQYDK2VwAyEAkg4rZnVkPajMUlNxpLYYGB8dkUW7nNqgSBi9IzMSaJc=';
const SIG = 'update-key2.sig';
const SIG_NAME = /(^|\/)update(-key2)?\.sig$/;
const SKIP = /(^|\/)(node_modules|dist|\.git|data)(\/|$)|(^|\/)__MACOSX\/|(^|\/)\._|\.DS_Store$/;
// What the signature covers: every file's name and contents (the same list Studio's updates sign)
const manifest = (entries) => entries.filter((e) => !SIG_NAME.test(e.name) && !SKIP.test(e.name))
  .map((e) => `${e.name}\0${crypto.createHash('sha256').update(e.data).digest('hex')}`).sort().join('\n');
const newer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
const readPkg = (dir) => { try { return JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')); } catch { return null; } };
// Which app: package.json "name" (electron-builder leaves "build", and so the app id, out of the built app)
const idOf = (pkg) => (pkg && pkg.name) || '';

// ---------- zips ----------
function unzip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 70000); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error("The update isn't a zip");
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const out = [];
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('The update looks damaged');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20);
    const nameLen = buf.readUInt16LE(p + 28), extraLen = buf.readUInt16LE(p + 30), commentLen = buf.readUInt16LE(p + 32);
    const local = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nameLen);
    p += 46 + nameLen + extraLen + commentLen;
    if (name.endsWith('/')) continue;
    const start = local + 30 + buf.readUInt16LE(local + 26) + buf.readUInt16LE(local + 28);
    const raw = buf.subarray(start, start + csize);
    const data = method === 0 ? raw : method === 8 ? zlib.inflateRawSync(raw) : null;
    if (!data) throw new Error(`Unsupported zip compression in ${name}`);
    out.push({ name, data });
  }
  return out;
}
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (b) => { let c = 0xffffffff; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
function zip(entries) {
  const parts = [], cen = [];
  let off = 0;
  for (const { name, data } of entries) {
    const nm = Buffer.from(name, 'utf8'), packed = zlib.deflateRawSync(data, { level: 9 }), crc = crc32(data);
    const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(8, 8);
    h.writeUInt32LE(crc, 14); h.writeUInt32LE(packed.length, 18); h.writeUInt32LE(data.length, 22); h.writeUInt16LE(nm.length, 26);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt16LE(8, 10);
    c.writeUInt32LE(crc, 16); c.writeUInt32LE(packed.length, 20); c.writeUInt32LE(data.length, 24); c.writeUInt16LE(nm.length, 28); c.writeUInt32LE(off, 42);
    parts.push(h, nm, packed); cen.push(c, nm); off += 30 + nm.length + packed.length;
  }
  const cd = Buffer.concat(cen), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cd, end]);
}

// The signature has to be there and match: anything else is refused.
function checkSignature(entries) {
  const sig = entries.find((e) => e.name === SIG || e.name.endsWith('/' + SIG));
  if (!sig) throw new Error('This update isn’t signed by Gotham Media House, so it wasn’t installed.');
  let ok = false;
  try { ok = crypto.verify(null, Buffer.from(manifest(entries), 'utf8'), crypto.createPublicKey({ key: Buffer.from(UPDATE_PUBLIC_KEY, 'base64'), format: 'der', type: 'spki' }), Buffer.from(sig.data.toString('utf8').trim(), 'base64')); } catch {}
  if (!ok) throw new Error('This update’s signature doesn’t match its contents (it was changed after Gotham Media House signed it), so it wasn’t installed.');
}

// ---------- starting the app ----------
let S = global.__scUpdate || null; // shared with the copy of this file inside an installed update

function boot(bundledDir, entry = 'main.js') {
  const { app } = require('electron');
  const updatesDir = path.join(app.getPath('userData'), 'updates');
  const currentDir = path.join(updatesDir, 'current'), previousDir = path.join(updatesDir, 'previous');
  applyPending(updatesDir);
  const bundled = readPkg(bundledDir) || {};
  const bundledVersion = bundled.version || '0.0.0';
  const versionIn = (dir) => (fs.existsSync(path.join(dir, entry)) && idOf(readPkg(dir)) === idOf(bundled) ? readPkg(dir).version : null);
  // An update that keeps falling over before it has run for a while is set aside (see markHealthy)
  const marker = path.join(updatesDir, 'starting.json');
  let updateVersion = versionIn(currentDir);
  if (updateVersion) {
    let m = null; try { m = JSON.parse(fs.readFileSync(marker, 'utf8')); } catch {}
    const tries = m && m.version === updateVersion ? m.tries || 0 : 0;
    if (tries >= 2) {
      console.error(`Update ${updateVersion} didn't finish starting, twice; going back`);
      setAside(updatesDir);
      try { fs.rmSync(marker, { force: true }); } catch {}
      updateVersion = versionIn(currentDir);
    } else if (updateVersion && !newer(bundledVersion, updateVersion)) {
      try { fs.writeFileSync(marker, JSON.stringify({ version: updateVersion, tries: tries + 1 })); } catch {}
    }
  }
  const useUpdate = !!updateVersion && !newer(bundledVersion, updateVersion);
  S = global.__scUpdate = { bundledDir, updatesDir, entry, appId: idOf(bundled), bundledVersion, deps: Object.keys(bundled.dependencies || {}),
    dir: useUpdate ? currentDir : bundledDir, version: useUpdate ? updateVersion : bundledVersion };
  // The version the app shows is the one running
  app.getVersion = () => S.version;
  if (useUpdate || fs.existsSync(previousDir)) {
    // Let an installed update find this build's libraries (koffi, ffmpeg-static…), even inside app.asar
    const Module = require('module');
    const libs = path.join(bundledDir, 'node_modules'), resolve = Module._resolveFilename;
    Module._resolveFilename = function (request, parent, isMain, options) {
      try { return resolve.call(this, request, parent, isMain, options); }
      catch (e) {
        if (request.startsWith('.') || path.isAbsolute(request)) throw e;
        return resolve.call(this, request, parent, isMain, { ...(options || {}), paths: [libs] });
      }
    };
  }
  // A window showing its page (or 20 seconds running) counts as started; then old folders are tidied away
  let started = false;
  const ok = () => { if (started) return; started = true; try { fs.rmSync(marker, { force: true }); } catch {} cleanup(updatesDir); };
  app.on('browser-window-created', (_e, w) => w.webContents.once('did-finish-load', ok));
  app.whenReady().then(() => setTimeout(ok, 20000));
  try { require(path.join(S.dir, entry)); }
  catch (e) {
    if (!useUpdate) throw e;
    console.error(`Update ${updateVersion} failed to start; going back`, e);
    setAside(updatesDir);
    const prev = versionIn(currentDir);
    if (prev && !newer(bundledVersion, prev)) {
      Object.assign(S, { dir: currentDir, version: prev });
      try { require(path.join(currentDir, entry)); return; } catch (e2) { console.error('The update before it failed too', e2); setAside(updatesDir); }
    }
    Object.assign(S, { dir: bundledDir, version: bundledVersion });
    require(path.join(bundledDir, entry));
  }
}
function setAside(updatesDir) {
  const current = path.join(updatesDir, 'current'), previous = path.join(updatesDir, 'previous');
  try { if (fs.existsSync(current)) fs.renameSync(current, path.join(updatesDir, `failed-${Date.now()}`)); } catch {}
  try { if (fs.existsSync(previous)) fs.renameSync(previous, current); } catch {}
}
// A downloaded update is swapped in at the next start, before any of its files are in use
function applyPending(updatesDir) {
  const current = path.join(updatesDir, 'current'), previous = path.join(updatesDir, 'previous'), next = path.join(updatesDir, 'next');
  try {
    if (!fs.existsSync(path.join(next, '.ready'))) return;
    const stamp = Date.now();
    if (fs.existsSync(previous)) fs.renameSync(previous, path.join(updatesDir, `removed-${stamp}`));
    if (fs.existsSync(current)) fs.renameSync(current, previous);
    fs.renameSync(next, current);
    fs.rmSync(path.join(current, '.ready'), { force: true });
  } catch (e) { console.error('Could not apply the update:', e.message); }
}
function cleanup(updatesDir) {
  try { for (const n of fs.readdirSync(updatesDir)) if (/^(removed|failed)-\d+$/.test(n)) fs.rmSync(path.join(updatesDir, n), { recursive: true, force: true }); } catch {}
}

// ---------- installing ----------
// Checks a downloaded zip and unpacks it into updates/next, ready for the next start.
function install(buf) {
  if (!S) throw new Error('Updates need the app to be started through sc-update.js');
  const all = unzip(buf);
  checkSignature(all);
  const entries = all.filter((e) => !SKIP.test(e.name) && !SIG_NAME.test(e.name));
  const pkgEntry = entries.filter((e) => /(^|\/)package\.json$/.test(e.name)).sort((a, b) => a.name.length - b.name.length)[0];
  let pkg = null; try { pkg = JSON.parse(pkgEntry.data.toString('utf8')); } catch {}
  if (!pkg || idOf(pkg) !== S.appId) throw new Error('That update is for a different app, so it wasn’t installed.');
  if (!newer(pkg.version, S.version)) throw new Error(`That update is ${pkg.version}, and ${S.version} is already running.`);
  const root = pkgEntry.name.slice(0, -'package.json'.length);
  const files = entries.filter((e) => e.name.startsWith(root)).map((e) => ({ rel: e.name.slice(root.length), data: e.data }));
  if (!files.some((f) => f.rel === S.entry)) throw new Error(`That update has no ${S.entry}, so it wasn’t installed.`);
  for (const dep of Object.keys(pkg.dependencies || {})) {
    if (!S.deps.includes(dep)) throw new Error(`This version needs "${dep}", which this copy doesn’t have. Download the full app from showcallerstudio.com instead.`);
  }
  // Catch a broken file before anything is replaced
  for (const f of files.filter((x) => /^[^/]+\.js$/.test(x.rel))) {
    try { new vm.Script(`(function (exports, require, module, __filename, __dirname) {${f.data.toString('utf8')}\n})`, { filename: f.rel }); }
    catch (e) { throw new Error(`${f.rel} in this update has a problem: ${e.message}`); }
  }
  const next = path.join(S.updatesDir, 'next');
  fs.rmSync(next, { recursive: true, force: true });
  fs.mkdirSync(next, { recursive: true });
  for (const f of files) {
    const dest = path.resolve(next, f.rel);
    if (!dest.startsWith(next + path.sep)) continue; // nothing may land outside the folder
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, f.data);
  }
  fs.writeFileSync(path.join(next, '.ready'), String(pkg.version));
  return pkg.version;
}

// Picks the zip details out of a /api/<app>/latest answer (main.js adds them to its update object)
function fromLatest(j) {
  const ok = (u) => /^https:\/\/\S+$/.test(String(u || '')) || (!require('electron').app.isPackaged && /^http:\/\/(127\.0\.0\.1|localhost)[:/]/.test(String(u || '')));
  return ok(j && j.zip) ? { zip: String(j.zip), sha256: /^[0-9a-f]{64}$/.test(j.sha256 || '') ? j.sha256 : null } : {};
}

let busy = false;
// "Update available": asks, downloads, installs, then offers to restart. Without a zip it opens the page.
async function offer(win, update, name) {
  const { app, dialog, shell, net } = require('electron');
  if (!update) return;
  if (!update.zip) { if (update.page) shell.openExternal(update.page); return; }
  if (busy) return;
  const appName = name || app.getName();
  const box = (o) => (win && !win.isDestroyed() ? dialog.showMessageBox(win, o) : dialog.showMessageBox(o));
  const { response } = await box({ type: 'info', buttons: ['Install Update', 'Later'], defaultId: 0, cancelId: 1,
    message: `${appName} ${update.version} is available.`,
    detail: `You have ${app.getVersion()}.${update.notes ? `\n\n${update.notes}` : ''}\n\nSettings and license stay as they are. It takes effect when ${appName} restarts.` });
  if (response !== 0) return;
  busy = true;
  const bar = (v) => { try { if (win && !win.isDestroyed()) win.setProgressBar(v); } catch {} };
  try {
    bar(2); // indeterminate while it downloads
    const r = await net.fetch(update.zip, { headers: { 'User-Agent': `${appName.replace(/\s+/g, '')}/${app.getVersion()}` } });
    if (!r.ok) throw new Error(`The download didn’t work (${r.status}). Try again later.`);
    const buf = Buffer.from(await r.arrayBuffer());
    if (update.sha256 && crypto.createHash('sha256').update(buf).digest('hex') !== update.sha256) throw new Error('The download was incomplete. Try again.');
    const v = install(buf);
    bar(-1);
    const { response: now } = await box({ type: 'info', buttons: ['Restart Now', 'Later'], defaultId: 0, cancelId: 1,
      message: `${appName} ${v} is installed.`, detail: `Restart ${appName} to start using it. If you choose Later, it starts the next time you open ${appName}.` });
    if (now === 0) { app.relaunch(); app.quit(); }
  } catch (e) {
    bar(-1);
    const { response: r2 } = await box({ type: 'warning', buttons: ['OK', 'Open Download Page'], defaultId: 0, cancelId: 0,
      message: 'The update wasn’t installed.', detail: e.message || String(e) });
    if (r2 === 1 && update.page) shell.openExternal(update.page);
  } finally { busy = false; }
}

// ---------- making an update zip (command line) ----------
function collect(appDir) {
  const pkg = readPkg(appDir);
  if (!pkg) throw new Error(`No package.json in ${appDir}`);
  const out = new Map();
  const walk = (rel) => {
    const abs = path.join(appDir, rel);
    if (!fs.existsSync(abs) || SKIP.test(rel)) return;
    if (fs.statSync(abs).isDirectory()) { for (const n of fs.readdirSync(abs)) walk(rel ? `${rel}/${n}` : n); }
    // package.json goes in as the built app has it, without "build" (copies up to 1.0 compare it)
    else out.set(rel, rel === 'package.json' ? Buffer.from(JSON.stringify({ ...pkg, build: undefined }, null, 2) + '\n') : fs.readFileSync(abs));
  };
  for (const pat of [...((pkg.build && pkg.build.files) || []), 'package.json', 'sc-update.js']) {
    if (typeof pat !== 'string' || pat.startsWith('!')) continue;
    walk(pat.replace(/\/\*\*(\/\*)?$/, '').replace(/\/\*$/, ''));
  }
  return { pkg, entries: [...out].sort(([a], [b]) => a.localeCompare(b)).map(([name, data]) => ({ name, data })) };
}
function pack(appDir, keyPath, outDir) {
  const { pkg, entries } = collect(appDir);
  if (pkg.main !== 'sc-update.js') throw new Error('package.json "main" must be sc-update.js');
  const sig = crypto.sign(null, Buffer.from(manifest(entries), 'utf8'), crypto.createPrivateKey(fs.readFileSync(keyPath, 'utf8')));
  const buf = zip([...entries, { name: SIG, data: Buffer.from(sig.toString('base64') + '\n') }]);
  checkSignature(unzip(buf)); // the key has to be the one the apps trust
  const file = path.join(outDir || path.join(appDir, '..', 'Releases'), `${pkg.name}-update-${pkg.version}.zip`);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, buf);
  return { app: idOf(pkg), version: pkg.version, file, size: buf.length, sha256: crypto.createHash('sha256').update(buf).digest('hex'), files: entries.length };
}

module.exports = { boot, install, offer, fromLatest, unzip, zip, manifest, checkSignature, collect, pack, newer };

if (process.versions.electron && process.type === 'browser') {
  // Electron's entry point (package.json "main"); not when main.js requires this file
  if (!global.__scUpdate && path.resolve(__dirname) === path.resolve(require('electron').app.getAppPath())) boot(__dirname);
} else if (require.main === module) {
  {
    const [cmd, dir, key, out] = process.argv.slice(2);
    if (cmd !== 'pack' || !dir || !key) { console.error('Use: node sc-update.js pack <app folder> <update-key.pem> [output folder]'); process.exit(1); }
    try { console.log(JSON.stringify(pack(path.resolve(dir), key, out && path.resolve(out)), null, 2)); }
    catch (e) { console.error(e.message); process.exit(1); }
  }
}
