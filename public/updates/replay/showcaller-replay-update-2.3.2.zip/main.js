// Showcaller Replay and Showcaller ISO · Gotham Media House (one app until 2.0, Showcaller ISO Recorder; edition.js says which this is)
// Records every chosen NDI source to its own file at the same time (ProRes or H.264), with matching time-of-day
// timecode and markers for the edit, and plays any of them back as an instant replay (any angle, any speed), out as
// an NDI source. Part of the paid Showcaller tools: a Showcaller Studio license key unlocks it, after a 14-day free trial.
const { app, BrowserWindow, ipcMain, Menu, powerSaveBlocker, shell, dialog, net } = require('electron');
const updater = require('./sc-update'); // one-click updates: downloads, checks and installs signed updates
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const ndi = require('./ndi');
const demo = require('./demo');
// Where pictures come from: NDI, and the practice cameras of demo mode ("DEMO (Wide)"…), which work the same way
const media = {
  watch: (n, u) => (demo.isDemo(n) ? demo.watch(n, u) : ndi.watch(n, u)),
  info: (n) => (demo.isDemo(n) ? demo.info(n) : ndi.info(n)),
  sources: () => [...ndi.sources(), ...demo.sources()],
  sender: (n) => ndi.sender(n),
  get state() { return ndi.state; },
};
const rec = require('./recorder');
const ED = require('./edition');
const { Replay } = require('./replay');
const http = require('http');

app.setName(ED.name);
if (process.env.ISO_USER_DATA) app.setPath('userData', path.resolve(process.env.ISO_USER_DATA)); // tests
if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }
const isMac = process.platform === 'darwin';

// ---------- settings ----------
const SETTINGS = path.join(app.getPath('userData'), 'settings.json');
// Settings (and the license key and trial) carry over from Showcaller ISO Recorder, as the app was called before 2.0
const OLD_SETTINGS = path.join(app.getPath('appData'), 'Showcaller ISO Recorder', 'settings.json');
if (!process.env.ISO_USER_DATA && !fs.existsSync(SETTINGS) && fs.existsSync(OLD_SETTINGS)) {
  try { fs.mkdirSync(path.dirname(SETTINGS), { recursive: true }); fs.copyFileSync(OLD_SETTINGS, SETTINGS); } catch {}
}
const defaults = () => ({
  // (from the home folder: app.getPath('movies') isn't available until the app is ready on a Mac)
  folder: path.join(os.homedir(), isMac ? 'Movies' : 'Videos', ED.iso ? 'Showcaller ISO' : 'Showcaller Replay'),
  codec: 'prores-422',
  sources: [], // the NDI sources ticked to record
  extraIps: '',
  takeName: '',
  licenseKey: '', trialStart: '',
  demo: false, // demo mode: three practice cameras
  replayOut: true, // send the replay out as an NDI source
  replayTag: true, // a REPLAY tag in the corner of replays
  preroll: 3, // seconds before a marker that cueing to it starts
  control: false, controlPort: 4780, // Stream Deck / Companion control over the network
  bounds: null,
});
let cfg = defaults();
try { cfg = { ...cfg, ...JSON.parse(fs.readFileSync(SETTINGS, 'utf8')) }; } catch {}
if (!Array.isArray(cfg.sources)) cfg.sources = [];
if (!rec.CODECS[cfg.codec]) cfg.codec = 'prores-422';
// the folder still named after the old app, unless it was chosen: the new name (old recordings stay where they are)
if (ED.replay && cfg.folder === path.join(os.homedir(), isMac ? 'Movies' : 'Videos', 'Showcaller ISO') && !fs.existsSync(cfg.folder)) cfg.folder = defaults().folder;
let saveTimer = null;
const writeNow = () => { try { fs.mkdirSync(path.dirname(SETTINGS), { recursive: true }); fs.writeFileSync(SETTINGS, JSON.stringify(cfg, null, 2)); } catch {} };
const save = () => { clearTimeout(saveTimer); saveTimer = setTimeout(writeNow, 300); };

// ---------- license (the same keys as Showcaller Studio, Timer Pro and Multiview) ----------
const TRIAL_DAYS = 14;
const LICENSE_PUBLIC_KEYS = [
  'MCowBQYDK2VwAyEAvpyichJqpB8vsa2+8x/TeadG602NYx/7RV4XjNVv5hA=', // Showcaller Studio Admin
  'MCowBQYDK2VwAyEAfcgnMJDltPQZq9dWAjzG6aOLeM9A+XCW74c4xWq+QWw=', // web store
  ...(!app.isPackaged && process.env.ISO_TEST_LICENSE_PUBKEY ? [process.env.ISO_TEST_LICENSE_PUBKEY] : []), // testing only
].map((k) => { try { return crypto.createPublicKey({ key: Buffer.from(k, 'base64'), format: 'der', type: 'spki' }); } catch { return null; } }).filter(Boolean);
function readLicense(str) {
  const s = String(str || '').replace(/\s+/g, '');
  if (!s) return { ok: false };
  const m = s.match(/^UPS2-([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/);
  if (!m) return { ok: false, error: 'That doesn’t look like a Showcaller Studio license key. Paste the whole key, starting with UPS2-.' };
  const body = Buffer.from(m[1], 'base64url'), sig = Buffer.from(m[2], 'base64url');
  if (!LICENSE_PUBLIC_KEYS.some((k) => { try { return crypto.verify(null, body, k, sig); } catch { return false; } })) return { ok: false, error: 'That key isn’t valid. It may be mistyped or cut short: paste it again.' };
  let k; try { k = JSON.parse(body.toString('utf8')); } catch {}
  if (!k || typeof k.to !== 'string') return { ok: false, error: 'That key can’t be read.' };
  const exp = /^\d{4}-\d{2}-\d{2}$/.test(String(k.exp || '')) ? k.exp : null;
  if (exp && Date.now() > new Date(`${exp}T23:59:59`).getTime()) return { ok: false, to: k.to, exp, error: `This license ended on ${exp}. Renew it to keep recording.` };
  return { ok: true, to: k.to, exp };
}
const today = () => new Date().toISOString().slice(0, 10);
if (!/^\d{4}-\d{2}-\d{2}$/.test(cfg.trialStart || '')) { cfg.trialStart = today(); writeNow(); }
function readPro() {
  const lic = readLicense(cfg.licenseKey);
  if (lic.ok) return { ...lic, licensed: true };
  const daysLeft = Math.max(0, TRIAL_DAYS - Math.floor((Date.now() - new Date(`${cfg.trialStart}T00:00:00`).getTime()) / 86400e3));
  return { ...lic, ok: daysLeft > 0, licensed: false, trial: daysLeft > 0, daysLeft };
}
let pro = readPro();

// ---------- windows ----------
let win = null;
const send = (ch, ...a) => { if (win && !win.isDestroyed()) win.webContents.send(ch, ...a); };
function createWindow() {
  const b = cfg.bounds || {};
  win = new BrowserWindow({
    width: b.width || 1440, height: b.height || 860, x: b.x, y: b.y, minWidth: 1100, minHeight: 640,
    backgroundColor: '#0b0c0e', title: ED.name, show: false,
    titleBarStyle: isMac ? 'hiddenInset' : 'default', autoHideMenuBar: !isMac,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'), { query: { edition: ED.edition } });
  win.once('ready-to-show', () => win.show());
  const keep = () => { if (!win.isMinimized() && !win.isFullScreen()) { cfg.bounds = win.getBounds(); save(); } };
  win.on('resize', keep); win.on('move', keep);
  win.on('close', (e) => { if (take && !quitting) { e.preventDefault(); askQuit(); } });
  win.on('closed', () => { win = null; });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https:\/\//.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e) => e.preventDefault());
}

// ---------- FFmpeg ----------
const bin = rec.ffmpegPath();
let encoders = {}, encodersReady = false;
const encoderReady = () => !!encoders[rec.CODECS[cfg.codec].kind];

// ---------- watching the sources (picture, sound meter, what they send) ----------
// Every ticked source is watched all the time (not just while recording), so you can see it's there before you
// press Record. The window gets a small moving picture (up to 25 a second, 15 with more than four sources, the next one only once it has drawn the
// last, so a busy or hidden window never piles them up) and the sound levels ten times a second.
const watched = new Map(); // name -> { stop, peak:[l,r], thumbAt, ... }
// A copy of the picture for the window, the size the window shows it at: every nth pixel pair, still as UYVY (or BGRA), so the main process
// only picks bytes out. The window turns it into colour.
const pickCache = new Map();
function thumb(f, want = 320) {
  const bpp = f.fmt === 'uyvy' ? 2 : 4, tw = Math.max(64, Math.min(f.w, want) & ~1), th = Math.max(2, Math.round((tw * f.h) / f.w / 2) * 2);
  const key = `${f.w}x${f.h}${f.fmt}>${tw}`;
  let cols = pickCache.get(key);
  if (!cols) { // byte offset in a source row of each output pixel (pairs, for UYVY)
    cols = new Int32Array(f.fmt === 'uyvy' ? tw / 2 : tw);
    for (let x = 0; x < cols.length; x++) cols[x] = f.fmt === 'uyvy' ? Math.floor((x * 2 * f.w) / tw / 2) * 4 : Math.floor((x * f.w) / tw) * 4;
    pickCache.set(key, cols);
  }
  const out = Buffer.allocUnsafe(tw * th * bpp), src = f.data, row = f.w * bpp, n = cols.length;
  let o = 0;
  for (let y = 0; y < th; y++) {
    const base = Math.floor((y * f.h) / th) * row;
    for (let x = 0; x < n; x++) { const i = base + cols[x]; out[o] = src[i]; out[o + 1] = src[i + 1]; out[o + 2] = src[i + 2]; out[o + 3] = src[i + 3]; o += 4; }
  }
  return { w: tw, h: th, fmt: f.fmt, data: out };
}
function syncWatching() {
  const want = new Set(cfg.sources.filter((n) => (demo.isDemo(n) ? demo.on : ndi.state.ok)));
  for (const [name, w] of watched) if (!want.has(name)) { w.stop(); watched.delete(name); }
  for (const name of want) {
    if (watched.has(name)) continue;
    const w = { peak: [0, 0], thumbAt: 0, ready: true, size: 320 };
    w.stop = media.watch(name, {
      frame: (f) => {
        const now = Date.now();
        if (now - w.thumbAt < (watched.size > 4 ? 66 : 40) || (!w.ready && now - w.thumbAt < 1000)) return; // (a lost "drawn" is given up after a second)
        w.thumbAt = now; w.ready = false;
        send('thumb', { name, ...thumb(f, w.size) });
      },
      audio: (a) => { let l = w.peak[0], r = w.peak[1]; for (let k = 0; k < a.n; k++) { const x = Math.abs(a.left[k]), y = Math.abs(a.right[k]); if (x > l) l = x; if (y > r) r = y; } w.peak = [l, r]; },
    });
    if (w.stop) watched.set(name, w);
  }
}
setInterval(() => {
  if (!watched.size) return;
  const levels = {};
  for (const [name, w] of watched) { levels[name] = w.peak; w.peak = [0, 0]; }
  send('levels', levels);
}, 100).unref?.();

// ---------- recording ----------
let take = null, stopping = null, blocker = null, lastTake = null, lastTakeObj = null;
const notices = [];
function notice(text, kind = 'warn') { notices.push({ at: Date.now(), text, kind }); while (notices.length > 30) notices.shift(); send('notice', { text, kind }); }
function disk() {
  try {
    const dir = fs.existsSync(cfg.folder) ? cfg.folder : path.dirname(cfg.folder);
    const s = fs.statfsSync(dir);
    return { free: s.bavail * s.bsize, total: s.blocks * s.bsize };
  } catch { return null; }
}
// How many bytes a second the take writes, from the last ten seconds
let rateWin = [];
function statusNow() {
  const all = media.sources(), sources = cfg.sources.map((name) => ({ name, ...(media.info(name) || {}), online: all.includes(name) }));
  const d = disk();
  let st = null, rate = 0;
  if (take) {
    st = take.status();
    const now = Date.now(), bytes = take.bytes();
    rateWin.push({ at: now, bytes }); rateWin = rateWin.filter((x) => now - x.at <= 10000);
    if (rateWin.length > 1) rate = (bytes - rateWin[0].bytes) / ((now - rateWin[0].at) / 1000);
    st.bytes = bytes; st.rate = rate;
  }
  return { take: st, stopping: !!stopping, sources, disk: d, secondsLeft: rate > 0 && d ? d.free / rate : null, lastTake };
}
setInterval(() => {
  const s = statusNow();
  send('status', s);
  if (take && s.disk && s.disk.free < 2e9 && !take.lowDiskWarned) { take.lowDiskWarned = true; notice('The recording drive is almost full (under 2 GB left).', 'bad'); }
}, 500).unref?.();

async function startRecording() {
  if (take || stopping) return { ok: false, error: 'Already recording.' };
  if (!pro.ok) { send('command', 'license'); return { ok: false, error: 'Recording needs a Showcaller Studio license key (the free trial has ended).' }; }
  if (!ndi.state.ok && !cfg.sources.every(demo.isDemo)) return { ok: false, error: ndi.state.reason };
  if (!bin) return { ok: false, error: `FFmpeg is missing from the app. Reinstall ${ED.name}.` };
  if (!encodersReady) return { ok: false, error: 'Still checking what this computer can record. Try again in a moment.' };
  if (!encoderReady()) return { ok: false, error: `This computer can’t record ${rec.CODECS[cfg.codec].label}. Pick another format in Settings.` };
  if (!cfg.sources.length) return { ok: false, error: 'Tick at least one source to record.' };
  try { fs.mkdirSync(cfg.folder, { recursive: true }); fs.accessSync(cfg.folder, fs.constants.W_OK); }
  catch { return { ok: false, error: `Can’t save to ${cfg.folder}. Pick another folder in Settings.` }; }
  try {
    take = new rec.Take({ ndi: media, bin, encoders, folder: cfg.folder, sources: cfg.sources.slice(), codec: cfg.codec, name: cfg.takeName });
  } catch (e) { take = null; return { ok: false, error: `Couldn’t start: ${e.message}` }; }
  rateWin = []; notices.length = 0;
  take.on('trouble', (name, m) => notice(name ? `${name}: ${m}` : m, 'bad'));
  take.on('gone', (name) => notice(`${name} went away. Its file carries on with the last picture until it comes back.`));
  take.on('back', (name) => notice(`${name} is back.`, 'ok'));
  // warn once if the computer can't keep up (FFmpeg not taking pictures fast enough): pictures left out for two
  // checks in a row, or more than a second's worth at once. A single short hiccup is just noted in Take info.txt.
  take.busyTimer = setInterval(() => {
    if (!take) return;
    for (const t of take.tracks) {
      const n = t.dropped - (t.droppedSeen || 0); t.droppedSeen = t.dropped;
      t.busyRun = n > 0 ? (t.busyRun || 0) + 1 : 0; t.busyNow = t.busyRun >= 2 || n > 30;
    }
    const busy = take.tracks.filter((t) => t.busyNow);
    if (busy.length && !take.busyWarned) { take.busyWarned = true; notice(`This computer isn’t keeping up with ${busy.length === take.tracks.length ? 'the sources' : busy.map((t) => t.name).join(', ')}: some frames are being repeated. Try a lighter format (ProRes LT or Proxy) or fewer sources.`, 'bad'); }
  }, 2000);
  blocker = powerSaveBlocker.start('prevent-app-suspension');
  buildMenu(); send('status', statusNow());
  return { ok: true, dir: take.dir };
}
async function stopRecording() {
  if (!take) return stopping || { ok: false };
  const t = take;
  stopping = (async () => {
    clearInterval(t.busyTimer);
    send('status', { ...statusNow(), stopping: true });
    const sum = await t.stop();
    take = null; lastTakeObj = t; // (still there to replay)
    if (blocker !== null) { try { powerSaveBlocker.stop(blocker); } catch {} blocker = null; }
    lastTake = { dir: sum.dir, folder: sum.folder, seconds: sum.seconds, bytes: sum.bytes, markers: sum.markers.length, files: sum.tracks.reduce((a, x) => a + x.parts, 0), tc: sum.tc,
      problems: sum.tracks.filter((x) => !x.parts || x.dropped || x.error).map((x) => x.name) };
    return { ok: true, ...lastTake };
  })();
  const r = await stopping;
  stopping = null;
  buildMenu(); send('status', statusNow());
  return r;
}
function mark(label) { return take ? take.mark(label) : null; }

async function askQuit() {
  const { response } = await dialog.showMessageBox(win, { type: 'warning', buttons: ['Stop and Quit', 'Keep Recording'], defaultId: 1, cancelId: 1,
    message: 'Stop recording and quit?', detail: 'The files are finished and saved first.' });
  if (response !== 0) return;
  await stopRecording();
  quitting = true; app.quit();
}

// ---------- replay ----------
// Replays come from the take that's recording, or else the last one. The output goes out as the NDI source
// "Showcaller Replay" (on the network as "THIS COMPUTER (Showcaller Replay)"): the chosen angle live, until a replay is cued.
let replay = null;
const replayPreview = { ready: true, thumbAt: 0, size: 960 };
function replayStatus() {
  const r = replay.status();
  const t = r.mode === 'replay' ? replay.take : take || lastTakeObj;
  r.markers = t ? t.markers.map((m) => ({ n: m.n, at: m.at, label: m.label, tc: m.tc })) : [];
  r.connections = replay.connections();
  r.recording = !!take && replay.take === take;
  r.licensed = pro.ok;
  return r;
}
let replaySendAt = 0, replaySendTimer = null;
function sendReplay() { // at most 20 times a second
  const wait = 50 - (Date.now() - replaySendAt);
  if (wait > 0) { if (!replaySendTimer) replaySendTimer = setTimeout(() => { replaySendTimer = null; sendReplay(); }, wait); return; }
  replaySendAt = Date.now(); send('replay', replayStatus());
}
function startReplay() {
  if (ED.iso) return; // (Showcaller ISO only records)
  replay = new Replay({ ndi: media, bin, take: () => take || lastTakeObj, sources: () => cfg.sources.slice() });
  replay.setTag(cfg.replayTag);
  replay.on('change', sendReplay);
  replay.on('error', (e) => console.error('replay', e));
  // the window's monitor: up to 25 a second, the next once it has drawn the last; a picture held back (as when
  // paused on one) goes a moment later, so the monitor always ends up on what's going out
  const preview = (f) => {
    const now = Date.now(), w = replayPreview;
    w.last = f;
    if (now - w.thumbAt < 40 || (!w.ready && now - w.thumbAt < 1000)) {
      if (!w.timer) w.timer = setTimeout(() => { w.timer = null; if (w.last) preview(w.last); }, w.ready ? 45 - (now - w.thumbAt) : 60);
      return;
    }
    w.thumbAt = now; w.ready = false; w.last = null;
    send('thumb', { name: '\u0000replay', ...thumb(f, w.size) });
  };
  replay.on('frame', preview);
  if (ndi.state.ok) replay.setOutput(cfg.replayOut);
  dropOwn();
  replay.setAngle(cfg.sources[0] || '');
  setInterval(() => { if (replay.mode === 'replay' || replay.enabled) sendReplay(); }, 100).unref?.();
}
// Every replay control, by name: from the window, the menu, and Stream Deck / Companion.
function replayCmd(cmd, a = {}) {
  if (!replay) return { ok: false, error: 'Replay isn’t ready.' };
  const num = (v, d) => (v === undefined || v === '' || Number.isNaN(Number(v)) ? d : Number(v));
  const angleByNumber = (n) => { const list = replay.status().angles; return list[Math.round(num(n, 0)) - 1]; };
  switch (cmd) {
    case 'cue': {
      if (a.marker != null) {
        const t = take || lastTakeObj, m = t?.markers.find((x) => x.n === Number(a.marker)) || (a.marker === 'last' ? t?.markers[t.markers.length - 1] : null);
        if (!m) return { ok: false, error: 'There’s no such marker.' };
        return replay.cue({ at: m.at - cfg.preroll * 1000, play: !!a.play });
      }
      return replay.cue({ seconds: num(a.seconds, 10), angle: a.angle != null ? (angleByNumber(a.angle) || String(a.angle)) : undefined, play: !!a.play });
    }
    case 'play': return replay.play(true);
    case 'pause': return replay.play(false);
    case 'toggle': return replay.play();
    case 'live': replay.live(); return { ok: true };
    case 'speed': return replay.setSpeed(num(a.value, 100) / 100);
    case 'faster': return replay.speedStep(1);
    case 'slower': return replay.speedStep(-1);
    case 'angle': { const name = a.name != null ? String(a.name) : angleByNumber(a.n); return name && replay.setAngle(name) ? { ok: true } : { ok: false, error: 'There’s no such angle.' }; }
    case 'step': replay.step(Math.round(num(a.frames, 1))); return { ok: true };
    case 'jump': { const s = replay.status(); if (s.mode !== 'replay') return { ok: false }; replay.seek(s.pos + num(a.seconds, 1) * 1000); return { ok: true }; }
    case 'seek': replay.seek(num(a.at, 0)); return { ok: true };
    case 'in': replay.markIn(); return { ok: true };
    case 'out': replay.markOut(); return { ok: true };
    case 'clip': return replay.saveClip(a.label);
    case 'clip-play': return replay.playClip(a.n == null ? null : num(a.n), { all: !!a.all });
    case 'clip-delete': replay.deleteClip(num(a.n)); return { ok: true };
    case 'clip-rename': replay.renameClip(num(a.n), a.label); return { ok: true };
    case 'tag-image': replay.setTagImage(a.img); return { ok: true };
    default: return { ok: false, error: `Unknown command ${cmd}` };
  }
}

// ---------- Stream Deck / Companion: control over the network ----------
// Off unless switched on in Settings. Bitfocus Companion's "Generic HTTP" module (or anything that can open a web
// address) presses the buttons: http://THIS-COMPUTER:4780/api/cue?seconds=10 and so on. GET or POST.
let control = null, controlState = { on: false, port: 0, error: '' };
const CONTROL = {
  record: () => startRecording(), stop: () => stopRecording(), mark: (q) => ({ ok: !!mark(q.label), error: take ? '' : 'Not recording.' }),
};
function startControl() {
  if (control) { try { control.close(); } catch {} control = null; }
  controlState = { on: false, port: cfg.controlPort, error: '' };
  if (!cfg.control) { send('control', controlState); return; }
  control = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x'), m = /^\/api\/([a-z-]+)(?:\/([a-z-]+))?$/.exec(u.pathname), q = Object.fromEntries(u.searchParams);
    const reply = (code, body) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }); res.end(JSON.stringify(body)); };
    if (!m) return reply(404, { ok: false, error: 'Try /api/state' });
    let cmd = m[1] + (m[2] ? `-${m[2]}` : '');
    if (cmd === 'speed-up') cmd = 'faster'; if (cmd === 'speed-down') cmd = 'slower'; if (cmd === 'clip-save') cmd = 'clip';
    if ('play' in q && q.play !== '0') q.play = true;
    if ('all' in q && q.all !== '0') q.all = true;
    try {
      if (cmd === 'state') return reply(200, { ok: true, recording: !!take, replay: replay ? replayStatus() : null });
      const r = CONTROL[cmd] ? await CONTROL[cmd](q) : cmd === 'tag-image' || !replay ? { ok: false, error: `Unknown command: ${cmd}` } : replayCmd(cmd, q);
      reply(r && r.ok === false && /Unknown/.test(r.error || '') ? 404 : 200, r || { ok: true });
    } catch (e) { reply(500, { ok: false, error: e.message }); }
  });
  control.on('error', (e) => { controlState.error = e.code === 'EADDRINUSE' ? `Port ${cfg.controlPort} is in use by another app. Pick another.` : e.message; controlState.on = false; send('control', controlState); });
  control.listen(cfg.controlPort, () => { controlState.on = true; send('control', controlState); });
}
const controlAddresses = () => Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);

// ---------- talking to the window ----------
const publicCfg = () => ({ ...cfg, bounds: undefined, licenseKey: undefined, pro });
ipcMain.handle('state', () => ({
  cfg: publicCfg(), version: app.getVersion(), platform: process.platform, codecs: Object.fromEntries(Object.entries(rec.CODECS).map(([k, v]) => [k, { label: v.label, mbps: v.mbps1080p30 }])),
  encoders, encodersReady, ffmpeg: !!bin, ndi: ndiInfo(), all: media.sources(), status: statusNow(), notices,
  replay: replay ? replayStatus() : null, control: controlState, addresses: controlAddresses(), host: os.hostname().replace(/\.local$/, ''),
}));
ipcMain.handle('replay', (_e, cmd, a) => replayCmd(String(cmd), a && typeof a === 'object' ? a : {}));
const ndiInfo = () => ({ ok: ndi.state.ok, reason: ndi.state.reason, link: ndi.state.link, needsRuntime: !!ndi.state.needsRuntime, version: ndi.state.version, builtIn: !!ndi.state.builtIn });
ipcMain.handle('settings', (_e, patch) => {
  if (!patch || typeof patch !== 'object') return publicCfg();
  if ('codec' in patch && rec.CODECS[patch.codec] && !take) cfg.codec = patch.codec;
  if ('demo' in patch && !take) setDemo(patch.demo);
  if ('replayOut' in patch) { cfg.replayOut = !!patch.replayOut; replay?.setOutput(cfg.replayOut); }
  if ('replayTag' in patch) { cfg.replayTag = !!patch.replayTag; replay?.setTag(cfg.replayTag); }
  if ('preroll' in patch) cfg.preroll = Math.max(0, Math.min(30, Number(patch.preroll) || 0));
  if ('control' in patch || 'controlPort' in patch) {
    if ('control' in patch) cfg.control = !!patch.control;
    if ('controlPort' in patch) { const n = Math.round(Number(patch.controlPort)); if (n >= 1024 && n <= 65535) cfg.controlPort = n; }
    startControl();
  }
  if ('takeName' in patch) cfg.takeName = String(patch.takeName || '').slice(0, 80);
  if (Array.isArray(patch.sources) && !take) {
    cfg.sources = [...new Set(patch.sources.map(String))].slice(0, 32); syncWatching();
    if (replay?.mode === 'live' && !cfg.sources.includes(replay.angle)) replay.setAngle(cfg.sources[0] || '');
  }
  if ('extraIps' in patch) {
    const v = String(patch.extraIps || '').split(/[\s,]+/).filter(Boolean).join(', ').slice(0, 500);
    if (v !== cfg.extraIps) { cfg.extraIps = v; ndi.setExtraIps(v); }
  }
  save();
  send('cfg', publicCfg());
  return publicCfg();
});
ipcMain.handle('pick-folder', async () => {
  if (take) return { ok: false };
  const r = await dialog.showOpenDialog(win, { title: 'Save recordings in', defaultPath: cfg.folder, properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths[0]) return { ok: false };
  cfg.folder = r.filePaths[0]; save(); send('cfg', publicCfg());
  return { ok: true, folder: cfg.folder };
});
ipcMain.handle('rec-start', () => startRecording());
ipcMain.handle('rec-stop', () => stopRecording());
ipcMain.handle('mark', (_e, label) => mark(label));
ipcMain.on('open-folder', (_e, dir) => {
  const d = String(dir || cfg.folder);
  if (d === cfg.folder || d === lastTake?.dir || d === take?.dir) { fs.mkdirSync(d, { recursive: true }); shell.openPath(d); }
});
ipcMain.on('open-link', (_e, url) => { if (update?.zip && url === update.page) return updater.offer(win, update); if (/^https:\/\//.test(String(url))) shell.openExternal(url); });
ipcMain.on('ndi-refresh', () => ndi.refresh());
ipcMain.on('thumb-ack', (_e, name) => { const w = name === '\u0000replay' ? replayPreview : watched.get(String(name)); if (w) w.ready = true; });
// How wide the window shows each source, in screen pixels, so its preview is sharp but no bigger than it needs to be
ipcMain.on('thumb-size', (_e, name, px) => { const w = name === '\u0000replay' ? replayPreview : watched.get(String(name)); if (w) w.size = Math.max(160, Math.min(1920, Math.round(Number(px) || 320))); });
ipcMain.on('buy', () => shell.openExternal('https://showcallerstudio.com/#pricing'));
ipcMain.handle('license-set', (_e, key) => {
  const r = readLicense(key);
  if (String(key || '').trim() && !r.ok) return { ...pro, error: r.error };
  cfg.licenseKey = String(key || '').replace(/\s+/g, '').slice(0, 2000); writeNow();
  pro = readPro(); send('cfg', publicCfg()); buildMenu();
  return pro;
});
// The replay output is never one of the sources (recording it would record the replays, and add an angle of itself)
function dropOwn() {
  if (take || !cfg.sources.some(ndi.isOwn)) return;
  cfg.sources = cfg.sources.filter((n) => !ndi.isOwn(n)); save(); syncWatching(); send('cfg', publicCfg());
}
ndi.events.on('sources', () => { dropOwn(); send('sources', media.sources()); });
// Demo mode: three practice cameras, ticked when it's switched on and gone when it's switched off
function setDemo(on) {
  on = !!on;
  if (take) return;
  cfg.demo = on;
  if (on) { demo.setOn(true); cfg.sources = [...new Set([...cfg.sources, ...demo.NAMES])]; }
  else cfg.sources = cfg.sources.filter((n) => !demo.isDemo(n));
  syncWatching();
  if (!on) demo.setOn(false);
  if (replay?.mode === 'live' && !cfg.sources.includes(replay.angle)) replay.setAngle(cfg.sources[0] || '');
  else if (on && replay?.mode === 'live' && !replay.angle) replay.setAngle(cfg.sources[0]);
  send('sources', media.sources());
}

// ---------- updates ----------
const UPDATE_URL = process.env.ISO_UPDATE_URL || `https://showcallerstudio.com/api/${ED.edition}/latest`;
let update = null;
const newer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
async function checkUpdate() {
  try {
    const r = await net.fetch(UPDATE_URL, { headers: { 'User-Agent': `${ED.name.replace(' ', '')}/${app.getVersion()}` } });
    if (!r.ok) return { ok: false, status: r.status };
    const j = await r.json();
    const page = [j?.url, j?.page].find((u) => /^https:\/\//.test(u || '')) || 'https://showcallerstudio.com/tools/';
    update = j && /^\d+\.\d+\.\d+$/.test(j.version || '') && newer(j.version, app.getVersion()) ? { version: j.version, notes: String(j.notes || '').slice(0, 300), page } : null;
    if (update) Object.assign(update, updater.fromLatest(j)); // the signed zip, when there is one
    send('update', update);
    return { ok: true, update };
  } catch { return { ok: false }; }
}

// ---------- menu ----------
function buildMenu() {
  const go = (c) => () => send('command', c);
  const tpl = [
    ...(isMac ? [{ label: app.name, submenu: [{ role: 'about' }, { type: 'separator' }, { label: 'Settings…', accelerator: 'Cmd+,', click: go('settings') }, { type: 'separator' }, { role: 'hide' }, { role: 'hideOthers' }, { role: 'unhide' }, { type: 'separator' }, { role: 'quit' }] }] : []),
    { label: 'File', submenu: [
      { label: 'Open Recordings Folder', accelerator: 'CmdOrCtrl+Shift+O', click: () => { fs.mkdirSync(cfg.folder, { recursive: true }); shell.openPath(take?.dir || cfg.folder); } },
      { label: 'Change Recordings Folder…', enabled: !take, click: go('folder') },
      { type: 'separator' },
      ...(isMac ? [] : [{ label: 'Settings…', accelerator: 'Ctrl+,', click: go('settings') }, { type: 'separator' }]),
      isMac ? { role: 'close' } : { role: 'quit' },
    ] },
    { label: 'Edit', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] },
    { label: 'Record', submenu: [
      { label: 'Start Recording', accelerator: 'CmdOrCtrl+R', enabled: !take, click: go('record') },
      { label: 'Stop Recording…', accelerator: 'CmdOrCtrl+.', enabled: !!take, click: go('stop') },
      { type: 'separator' },
      // M is handled by the window, so typing in a box still works
      { label: 'Add Marker    M', enabled: !!take, click: go('mark') },
      { type: 'separator' },
      { label: 'Look for NDI Sources Again', click: () => ndi.refresh() },
    ] },
    // (these keys are handled by the window, so typing in a box still works)
    ...(ED.iso ? [] : [{ label: 'Replay', submenu: [
      { label: 'Cue 5 Seconds Back    Q', click: go('cue5') },
      { label: 'Cue 10 Seconds Back    W', click: go('cue10') },
      { label: 'Cue 30 Seconds Back    E', click: go('cue30') },
      { label: 'Cue the Last Marker    R', click: go('cueMarker') },
      { type: 'separator' },
      { label: 'Play / Pause    Space', click: go('toggle') },
      { label: 'Slower    ↓', click: go('slower') },
      { label: 'Faster    ↑', click: go('faster') },
      { label: 'Back to Live    L', click: go('live') },
      { type: 'separator' },
      { label: 'Mark In    I', click: go('in') },
      { label: 'Mark Out    O', click: go('out') },
      { label: 'Save Clip    C', click: go('clip') },
      { label: 'Play All Clips    P', click: go('playAll') },
    ] }]),
    { label: 'View', submenu: [{ role: 'togglefullscreen' }, ...(app.isPackaged ? [] : [{ type: 'separator' }, { role: 'toggleDevTools' }, { role: 'reload' }])] },
    { role: 'windowMenu' },
    { role: 'help', submenu: [
      { label: 'Check for Updates…', click: async () => {
        const r = await checkUpdate();
        if (r.update?.zip) return updater.offer(win, r.update);
        const msg = !r.ok ? { message: 'Couldn’t check for updates.', detail: r.status ? 'The update service isn’t answering right now. Try again later.' : 'Check the internet connection and try again.' }
          : r.update ? { message: `${ED.name} ${r.update.version} is available.`, detail: `You have ${app.getVersion()}.${r.update.notes ? `\n\n${r.update.notes}` : ''}`, buttons: ['Get it', 'Later'] }
            : { message: `${ED.name} is up to date.`, detail: `Version ${app.getVersion()}` };
        const { response } = await dialog.showMessageBox(win, { type: 'info', buttons: ['OK'], ...msg });
        if (r.update && response === 0) shell.openExternal(r.update.page);
      } },
      { type: 'separator' },
      { label: 'Showcaller Tools', click: () => shell.openExternal('https://showcallerstudio.com/tools/') },
      { label: 'Showcaller Studio', click: () => shell.openExternal('https://showcallerstudio.com') },
    ] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(tpl));
}

// ---------- start ----------
let quitting = false;
app.whenReady().then(async () => {
  app.setAboutPanelOptions?.({ applicationName: ED.name, applicationVersion: app.getVersion(), copyright: '© 2026 Gotham Media House · showcallerstudio.com' });
  if (isMac && app.dock) { try { app.dock.setIcon(path.join(__dirname, 'build', 'icon.png')); } catch {} }
  buildMenu();
  ndi.start({ extraIps: cfg.extraIps.trim(), extraDirs: [path.join(process.resourcesPath || __dirname, 'ndi'), path.join(__dirname, 'ndi')] });
  if (cfg.demo) demo.setOn(true); else cfg.sources = cfg.sources.filter((n) => !demo.isDemo(n));
  syncWatching();
  startReplay();
  startControl();
  createWindow();
  encoders = await rec.detectEncoders(bin);
  encodersReady = true;
  send('encoders', encoders);
  setTimeout(checkUpdate, 8000); setInterval(checkUpdate, 6 * 3600 * 1000);
  setInterval(() => { const n = readPro(); if (n.ok !== pro.ok || n.daysLeft !== pro.daysLeft) { pro = n; send('cfg', publicCfg()); } }, 3600e3);
  if (process.env.ISO_TEST) { try { require(process.env.ISO_TEST)({ app, ipcMain, getWin: () => win, cfg, ndi, rec, replay }); } catch (e) { console.error(e); } }
});
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('activate', () => { if (!win) createWindow(); });
app.on('window-all-closed', () => app.quit());
let ending = false;
app.on('before-quit', (e) => {
  if (take && !quitting) { e.preventDefault(); askQuit(); return; }
  clearTimeout(saveTimer);
  quitting = true; writeNow();
  if (ending) return;
  // let the NDI receiver threads finish before the app goes (quitting under them can crash it)
  ending = true; e.preventDefault();
  (async () => {
    if (take) await stopRecording();
    try { replay?.close(); } catch {}
    try { control?.close(); } catch {}
    for (const w of watched.values()) w.stop();
    ndi.stop();
    setTimeout(() => app.exit(0), ndi.state.ok ? 600 : 0);
  })();
});
